﻿		</div>
		<script type="text/javascript" src="/application/public/widgets/jgrowl-notifications/jgrowl.js">
		<script type="text/javascript" src="/application/public/widgets/dropdown/dropdown.js"></script>
		<script type="text/javascript" src="/application/public/widgets/tooltip/tooltip.js"></script>
		<script type="text/javascript" src="/application/public/widgets/popover/popover.js"></script>
		<script type="text/javascript" src="/application/public/widgets/progressbar/progressbar.js"></script>
		<script type="text/javascript" src="/application/public/widgets/button/button.js"></script>
		<script type="text/javascript" src="/application/public/widgets/collapse/collapse.js"></script>
		<script type="text/javascript" src="/application/public/widgets/superclick/superclick.js"></script>
		<script type="text/javascript" src="/application/public/widgets/input-switch/inputswitch-alt.js"></script>
		<script type="text/javascript" src="/application/public/widgets/slimscroll/slimscroll.js"></script>
		<script type="text/javascript" src="/application/public/widgets/slidebars/slidebars.js"></script>
		<script type="text/javascript" src="/application/public/widgets/slidebars/slidebars-demo.js"></script>
		<script type="text/javascript" src="/application/public/widgets/charts/piegage/piegage.js"></script>
		<script type="text/javascript" src="/application/public/widgets/charts/piegage/piegage-demo.js"></script>
		<script type="text/javascript" src="/application/public/widgets/screenfull/screenfull.js"></script>
		<script type="text/javascript" src="/application/public/widgets/content-box/contentbox.js"></script>
		<script type="text/javascript" src="/application/public/widgets/material/material.js"></script>
		<script type="text/javascript" src="/application/public/widgets/material/ripples.js"></script>
		<script type="text/javascript" src="/application/public/widgets/overlay/overlay.js"></script>
		<script type="text/javascript" src="/application/public/js-init/widgets-init.js"></script>
		<script type="text/javascript" src="/application/public/themes/admin/layout.js"></script>
	</body>
</html>