﻿<!DOCTYPE html>
<html lang="ru">
	<head>
		<style>#loading .svg-icon-loader {position: absolute;top: 50%;left: 50%;margin: -50px 0 0 -50px;}</style>
		<meta charset="utf-8">
		<meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1'>
		<title><?php echo $title ?></title>
		<meta name="description" content="<?php echo $description ?>">
		<meta name="keywords" content="<?php echo $keywords ?>">
		<meta name="generator" content="">
		<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
		<link rel="stylesheet" type="text/css" href="/application/public/helpers/animate.css">
		<link rel="stylesheet" type="text/css" href="/application/public/helpers/boilerplate.css">
		<link rel="stylesheet" type="text/css" href="/application/public/helpers/border-radius.css">
		<link rel="stylesheet" type="text/css" href="/application/public/helpers/grid.css">
		<link rel="stylesheet" type="text/css" href="/application/public/helpers/page-transitions.css">
		<link rel="stylesheet" type="text/css" href="/application/public/helpers/spacing.css">
		<link rel="stylesheet" type="text/css" href="/application/public/helpers/typography.css">
		<link rel="stylesheet" type="text/css" href="/application/public/helpers/utils.css">
		<link rel="stylesheet" type="text/css" href="/application/public/helpers/colors.css">
		<link rel="stylesheet" type="text/css" href="/application/public/material/ripple.css">
		<link rel="stylesheet" type="text/css" href="/application/public/elements/badges.css">
		<link rel="stylesheet" type="text/css" href="/application/public/elements/buttons.css">
		<link rel="stylesheet" type="text/css" href="/application/public/elements/content-box.css">
		<link rel="stylesheet" type="text/css" href="/application/public/elements/dashboard-box.css">
		<link rel="stylesheet" type="text/css" href="/application/public/elements/forms.css">
		<link rel="stylesheet" type="text/css" href="/application/public/elements/images.css">
		<link rel="stylesheet" type="text/css" href="/application/public/elements/info-box.css">
		<link rel="stylesheet" type="text/css" href="/application/public/elements/invoice.css">
		<link rel="stylesheet" type="text/css" href="/application/public/elements/loading-indicators.css">
		<link rel="stylesheet" type="text/css" href="/application/public/elements/menus.css">
		<link rel="stylesheet" type="text/css" href="/application/public/elements/panel-box.css">
		<link rel="stylesheet" type="text/css" href="/application/public/elements/response-messages.css">
		<link rel="stylesheet" type="text/css" href="/application/public/elements/responsive-tables.css">
		<link rel="stylesheet" type="text/css" href="/application/public/elements/ribbon.css">
		<link rel="stylesheet" type="text/css" href="/application/public/elements/social-box.css">
		<link rel="stylesheet" type="text/css" href="/application/public/elements/tables.css">
		<link rel="stylesheet" type="text/css" href="/application/public/elements/tile-box.css">
		<link rel="stylesheet" type="text/css" href="/application/public/elements/timeline.css">
		<link rel="stylesheet" type="text/css" href="/application/public/icons/fontawesome/fontawesome.css">
		<link rel="stylesheet" type="text/css" href="/application/public/icons/linecons/linecons.css">
		<link rel="stylesheet" type="text/css" href="/application/public/icons/spinnericon/spinnericon.css">
		<link rel="stylesheet" type="text/css" href="/application/public/widgets/accordion-ui/accordion.css">
		<link rel="stylesheet" type="text/css" href="/application/public/widgets/calendar/calendar.css">
		<link rel="stylesheet" type="text/css" href="/application/public/widgets/carousel/carousel.css">
		<link rel="stylesheet" type="text/css" href="/application/public/widgets/charts/justgage/justgage.css">
		<link rel="stylesheet" type="text/css" href="/application/public/widgets/charts/morris/morris.css">
		<link rel="stylesheet" type="text/css" href="/application/public/widgets/charts/piegage/piegage.css">
		<link rel="stylesheet" type="text/css" href="/application/public/widgets/charts/xcharts/xcharts.css">
		<link rel="stylesheet" type="text/css" href="/application/public/widgets/chosen/chosen.css">
		<link rel="stylesheet" type="text/css" href="/application/public/widgets/colorpicker/colorpicker.css">
		<link rel="stylesheet" type="text/css" href="/application/public/widgets/datatable/datatable.css">
		<link rel="stylesheet" type="text/css" href="/application/public/widgets/datepicker/datepicker.css">
		<link rel="stylesheet" type="text/css" href="/application/public/widgets/datepicker-ui/datepicker.css">
		<link rel="stylesheet" type="text/css" href="/application/public/widgets/daterangepicker/daterangepicker.css">
		<link rel="stylesheet" type="text/css" href="/application/public/widgets/dialog/dialog.css">
		<link rel="stylesheet" type="text/css" href="/application/public/widgets/dropdown/dropdown.css">
		<link rel="stylesheet" type="text/css" href="/application/public/widgets/dropzone/dropzone.css">
		<link rel="stylesheet" type="text/css" href="/application/public/widgets/file-input/fileinput.css">
		<link rel="stylesheet" type="text/css" href="/application/public/widgets/input-switch/inputswitch.css">
		<link rel="stylesheet" type="text/css" href="/application/public/widgets/input-switch/inputswitch-alt.css">
		<link rel="stylesheet" type="text/css" href="/application/public/widgets/ionrangeslider/ionrangeslider.css">
		<link rel="stylesheet" type="text/css" href="/application/public/widgets/jcrop/jcrop.css">
		<link rel="stylesheet" type="text/css" href="/application/public/widgets/jgrowl-notifications/jgrowl.css">
		<link rel="stylesheet" type="text/css" href="/application/public/widgets/loading-bar/loadingbar.css">
		<link rel="stylesheet" type="text/css" href="/application/public/widgets/maps/vector-maps/vectormaps.css">
		<link rel="stylesheet" type="text/css" href="/application/public/widgets/markdown/markdown.css">
		<link rel="stylesheet" type="text/css" href="/application/public/widgets/modal/modal.css">
		<link rel="stylesheet" type="text/css" href="/application/public/widgets/multi-select/multiselect.css">
		<link rel="stylesheet" type="text/css" href="/application/public/widgets/multi-upload/fileupload.css">
		<link rel="stylesheet" type="text/css" href="/application/public/widgets/nestable/nestable.css">
		<link rel="stylesheet" type="text/css" href="/application/public/widgets/noty-notifications/noty.css">
		<link rel="stylesheet" type="text/css" href="/application/public/widgets/popover/popover.css">
		<link rel="stylesheet" type="text/css" href="/application/public/widgets/pretty-photo/prettyphoto.css">
		<link rel="stylesheet" type="text/css" href="/application/public/widgets/progressbar/progressbar.css">
		<link rel="stylesheet" type="text/css" href="/application/public/widgets/range-slider/rangeslider.css">
		<link rel="stylesheet" type="text/css" href="/application/public/widgets/slidebars/slidebars.css">
		<link rel="stylesheet" type="text/css" href="/application/public/widgets/slider-ui/slider.css">
		<link rel="stylesheet" type="text/css" href="/application/public/widgets/summernote-wysiwyg/summernote-wysiwyg.css">
		<link rel="stylesheet" type="text/css" href="/application/public/widgets/tabs-ui/tabs.css">
		<link rel="stylesheet" type="text/css" href="/application/public/widgets/timepicker/timepicker.css">
		<link rel="stylesheet" type="text/css" href="/application/public/widgets/tocify/tocify.css">
		<link rel="stylesheet" type="text/css" href="/application/public/widgets/tooltip/tooltip.css">
		<link rel="stylesheet" type="text/css" href="/application/public/widgets/touchspin/touchspin.css">
		<link rel="stylesheet" type="text/css" href="/application/public/widgets/uniform/uniform.css">
		<link rel="stylesheet" type="text/css" href="/application/public/widgets/wizard/wizard.css">
		<link rel="stylesheet" type="text/css" href="/application/public/widgets/xeditable/xeditable.css">
		<link rel="stylesheet" type="text/css" href="/application/public/snippets/chat.css">
		<link rel="stylesheet" type="text/css" href="/application/public/snippets/files-box.css">
		<link rel="stylesheet" type="text/css" href="/application/public/snippets/login-box.css">
		<link rel="stylesheet" type="text/css" href="/application/public/snippets/notification-box.css">
		<link rel="stylesheet" type="text/css" href="/application/public/snippets/progress-box.css">
		<link rel="stylesheet" type="text/css" href="/application/public/snippets/todo.css">
		<link rel="stylesheet" type="text/css" href="/application/public/snippets/user-profile.css">
		<link rel="stylesheet" type="text/css" href="/application/public/snippets/mobile-navigation.css">
		<link rel="stylesheet" type="text/css" href="/application/public/applications/mailbox.css">
		<link rel="stylesheet" type="text/css" href="/application/public/themes/admin/layout.css">
		<link rel="stylesheet" type="text/css" href="/application/public/themes/admin/color-schemes/default.css">
		<link rel="stylesheet" type="text/css" href="/application/public/themes/components/default.css">
		<link rel="stylesheet" type="text/css" href="/application/public/themes/components/border-radius.css">
		<link rel="stylesheet" type="text/css" href="/application/public/helpers/responsive-elements.css">
		<link rel="stylesheet" type="text/css" href="/application/public/helpers/admin-responsive.css">
		<script type="text/javascript" src="/application/public/js-core/jquery-core.js"></script>
		<script type="text/javascript" src="/application/public/js-core/jquery-ui-core.js"></script>
		<script type="text/javascript" src="/application/public/js-core/jquery-ui-widget.js"></script>
		<script type="text/javascript" src="/application/public/js-core/jquery-ui-mouse.js"></script>
		<script type="text/javascript" src="/application/public/js-core/jquery-ui-position.js"></script>
		<script type="text/javascript" src="/application/public/js-core/transition.js"></script>
		<script type="text/javascript" src="/application/public/js-core/modernizr.js"></script>
		<script type="text/javascript" src="/application/public/js-core/jquery-cookie.js"></script>
		<script type="text/javascript">$(window).load(function(){
			setTimeout(function() {
			    $('#loading').fadeOut( 400, "linear" );
			}, 300);
			});
		</script>
		<script type="text/javascript" src="/application/public/js-control-panel/jquery.min.js"></script>
		<script type="text/javascript" src="/application/public/js-control-panel/jquery.form.min.js"></script>
		<script type="text/javascript" src="/application/public/js-control-panel/jquery.flot.min.js"></script>
		<script type="text/javascript" src="/application/public/js-control-panel/jquery.flot.time.min.js"></script>
		<script type="text/javascript" src="/application/public/js-control-panel/bootstrap.min.js"></script>
		<script type="text/javascript" src="/application/public/js-control-panel/main.js"></script>
		<script src="/application/public/js-core/sweetalert.min.js"></script>
	</head>
	<body>
		<div id="sb-site">
			<div id="loading">
				<div class="svg-icon-loader"><img src="/application/public/images/svg-loaders/oval.svg" width="40" alt=""></div>
			</div>
			<div id="page-wrapper">
				<div id="mobile-navigation"><button id="nav-toggle" class="collapsed" data-toggle="collapse" data-target="#page-sidebar"><span></span></button></div>
				<div id="page-sidebar">
					<div id="header-logo" class="logo-bg">
						<a href="/" class="logo-content-big">AquzaPL<span>Панель управления серверами</span></a>
						<a href="/" class="logo-content-small">AquzaPL<span>Панель управления серверами</span></a>
						<a id="close-sidebar" href="#"><i class="glyph-icon icon-outdent"></i></a>
					</div>
					<div class="scroll-sidebar">
						<ul id="sidebar-menu">
							<li><a href="/main/index"><i class="glyph-icon icon-home"></i> <span>Главная</span></a></li>
							<li>
								<a href="#"><i class="glyph-icon icon-hdd-o"></i> <span>Сервера</span></a>
								<div class="sidebar-submenu">
									<ul>
										<li><a href="/servers/order"><span>Заказать сервер</span></a></li>
										<li><a href="/servers/index"><span>Мои сервера</span></a></li>
									</ul>
								</div>
							</li>
							<li>
								<a href="#"><i class="glyph-icon icon-users"></i> <span>Поддержка</span></a>
								<div class="sidebar-submenu">
									<ul>
										<li><a href="/tickets/create"><span>Создать запрос</span></a></li>
										<li><a href="/tickets/index"><span>Мои запросы</span></a></li>
									</ul>
								</div>
							</li>
							<li>
								<a href="#"><i class="glyph-icon icon-gear"></i> <span>Аккаунт</span></a>
								<div class="sidebar-submenu">
									<ul>
										<li><a href="/account/ref"><span>Реферальная программа</span></a></li>
										<li><a href="/account/perevod"><span>Перевод</span></a></li>
										<li><a href="/account/pay"><span>Пополнение баланса</span></a></li>
										<li><a href="/account/invoices"><span>Мои счета</span></a></li>
										<li><a href="/account/edit"><span>Настройки</span></a></li>
										<li><a href="/account/logout"><span>Выход</span></a></li>
									</ul>
								</div>
							</li>
							<li>
							<a href="/account/pay"><i class="glyph-icon icon-credit-card"></i> <span>Баланс: <?php echo $user_balance ?> ₽</span></a>
							</li>						
						</ul>
					</div>
				</div>
				<div id="page-content-wrapper">
					<div id="page-content">
						<div id="page-header">
							<div id="header-nav-right">
								<a href="#" class="button1 small" style="margin: 20px; border-radius: 15px; margin-left: 8px;"><h6 align="center">Баланс: <span><?php echo $user_balance;?></span></h6></a>
								<?php if($user_access_level >= 2): ?>
									<a href="/admin" class="button1 small" style="float:right; margin: 20px; border-radius: 15px; margin-left: 8px;"><h6>Админ центр</h6></a>
								<?php endif; ?>
								<a href="https://vk.com/public<?php echo $public ?>" class="hdr-btn" title="Мы ВКонтакте"><h2><i class="glyph-icon icon-vk"></i></h2></a>
							</div>
						</div>