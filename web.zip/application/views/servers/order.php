<?php echo $header ?>
<div class="row">
	<div class="col-md-6">
		<div class="content-box">
			<h3 class="content-box-header bg-default">Заказать сервер</h3>
			<div class="content-box-wrapper">
				<form class="form-horizontal" action="#" id="orderForm" method="POST">
					<div class="form-group">
						<label for="game" class="col-sm-3 control-label">Игра:</label>
						<div class="col-sm-6">
							<select class="form-control" id="gameid" name="gameid" onChange="updateForm()">
								<?php foreach($games as $item): ?> 
								<option value="<?php echo $item['game_id'] ?>"><?php echo $item['game_name'] ?></option>
								<?php endforeach; ?> 
							</select>
						</div>
					</div>
					<div class="form-group">
						<label for="location" class="col-sm-3 control-label">Локация:</label>
						<div class="col-sm-6">
							<select class="form-control" id="locationid" name="locationid">
								<?php foreach($locations as $item): ?> 
								<option value="<?php echo $item['location_id'] ?>"><?php echo $item['location_name'] ?></option>
								<?php endforeach; ?> 
							</select>
						</div>
					</div>
					<div class="form-group">
						<label for="months" class="col-sm-3 control-label">Период оплаты:</label>
						<div class="col-sm-6">
							<select class="form-control" id="months" name="months" onChange="updateForm()">
								<option value="1">1 месяц</option>
								<option value="3">3 месяца (-5%)</option>
								<option value="6">6 месяцев (-10%)</option>
								<option value="12">12 месяцев (-15%)</option>
							</select>
						</div>
					</div>
					<div class="form-group">
						<label for="months" class="col-sm-3 control-label">Количество слотов:</label>
						<div class="col-sm-6">
							<div class="input-group">
								<span class="input-group-btn"><button class="button1 primary" type="button" onClick="minusSlots10()"><<</button></span>
								<span class="input-group-btn"><button class="btn btn-default" type="button" onClick="minusSlots()">-</button></span>
								<input type="text" class="form-control" id="slots" name="slots" onChange="updateForm()">
								<span class="input-group-btn"><button class="btn btn-default" type="button" onClick="plusSlots()">+</button></span>
								<span class="input-group-btn"><button class="button1 success" type="button" onClick="plusSlots10()">>></button></span>
							</div>
						</div>
					</div>
					<div class="form-group">
						<label for="password" class="col-sm-3 control-label">Пароль:</label>
						<div class="col-sm-6">
							<input type="password" class="form-control" id="password" name="password" placeholder="Введите пароль">
						</div>
					</div>
					<div class="form-group">
						<label for="password2" class="col-sm-3 control-label">Повторите пароль:</label>
						<div class="col-sm-6">
							<input type="password" class="form-control" id="password2" name="password2" placeholder="Повторите пароль">
						</div>
					</div>
						<div class="form-group">
							<label for="promo" class="col-sm-3 control-label">Промокод:</label>  
							<div class="col-sm-6">							
                            <input id="promo" type="text" class="form-control" type="promo" name="promo" placeholder="Купон">
                            <button type="button" onclick="promoCode()" class="button1 primary" data-hover="Применить купон"><i class="fa fa-check"></i>Применить купон</button>
							</div>							
                        </div>
					<div class="form-group">
						<label for="price" class="col-sm-3 control-label">Итого:</label>
						<div class="col-sm-5">
							<p class="lead" id="price">0.00 руб.</p>
						</div>
					</div>
					<div class="form-group">
						<div class="col-sm-offset-3 col-sm-9">
							<button type="submit" class="button1 primary" data-hover="Заказать">Заказать</button>
							<button type="button" class="button1 success" data-hover="Сгенерировать пароль" onClick="generatePass()">Сгенерировать пароль</button>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
	<div class="col-md-6">
		<div class="content-box" data-sortable-id="ui-typography-5">
			<h3 class="content-box-header bg-default">Информация о заказе</h3>
			<div class="content-box-wrapper">
				<ul>
					<li>Автоматический заказ и установка сервера в течение минуты.</li>
					<li>Круглосуточная работа сервера.</li>
					<li>Бесплатная техническая поддержка.</li>
					<li>Возможность изменять слоты.</li>
					<li>Удобное управление сервером через нашу панель управления.</li>
					<li>Минимальный пинг.</li>
					<li>Полный FTP доступ для установки любых сборок, карт, модов, плагинов.</li>
					<li>Автоматический запуск сервера после падения или зависания.</li>
					<li>Статистика нагрузки сервера.</li>
					<li>Статистика маскимального онлайна сервера.</li>
					<li>Бесплатная база данных MySQL.</li>
				</ul>
			</div>
		</div>
	</div>
</div>
<script>
	var gameData = {
	<?php foreach($games as $item): ?> 
		<?php echo $item['game_id'] ?>: {
			'minslots': <?php echo $item['game_min_slots'] ?>,
			'maxslots': <?php echo $item['game_max_slots'] ?>,
			'price': <?php echo $item['game_price'] ?>
		},
	<?php endforeach; ?> 
	};
	$('#orderForm').ajaxForm({ 
		url: '/servers/order/ajax',
		dataType: 'text',
		success: function(data) {
			console.log(data);
			data = $.parseJSON(data);
			switch(data.status) {
				case 'error':
					//showError(data.error);
					swal("Ошибка", data.error, "error");
					//$.jGrowl(data.error, { sticky: !1, position: "top-right", theme: "bg-red" });
					$('button[type=submit]').prop('disabled', false);
					break;
				case 'success':
					//showSuccess(data.success);
					swal("Успешно", data.success, "success");
					//$.jGrowl(data.success, { sticky: !1, position: "top-right", theme: "bg-green" });
					if(data.url){
						//setTimeout("redirect("+data.url+")", 1500);
						setTimeout("redirect('/servers/control/index/" + data.id + "')", 1500);
					}else{
						setTimeout("redirect('/servers/control/index/" + data.id + "')", 1500);
					}
					//setTimeout("redirect('/')", 1500);
					break;
			}
		},
		beforeSubmit: function(arr, $form, options) {
			$('button[type=submit]').prop('disabled', true);
		}
	});
	$(document).ready(function() {
		updateForm();
	});
					function promoCode(){
						var promo = $("#promo").val();
						$.post("/servers/order/promo",{code: promo},function(data){
							data = $.parseJSON(data);
							switch(data.status) {
								case 'error':
									swal(data.error);
									updateForm();
									break;
								case 'success':
									swal(data.success);
									updateForm(data.skidka);
									break;
							}
						});
						
					}
					
					function updateForm(promo) {
						var gameID = $("#gameid option:selected").val();
						var slots = $("#slots").val();
						if(slots < gameData[gameID]['minslots']) {
							slots = gameData[gameID]['minslots'];
							$("#slots").val(slots);
						}
						if(slots > gameData[gameID]['maxslots']) {
							slots = gameData[gameID]['maxslots'];
							$("#slots").val(slots);
						}
						var price = gameData[gameID]['price'] * slots;
						var months = $("#months option:selected").val();
						switch(months) {
							case "3":
								price = 3 * price * 0.95;
								break;
							case "6":
								price = 6 * price * 0.90;
								break;
							case "12":
								price = 12 * price * 0.85;
								break;
						}
						if(promo != null){price = price * promo;}
						
						$('#price').text(price.toFixed(2) + ' руб.');
					}
	function plusSlots() {
		value = parseInt($('#slots').val());
		$('#slots').val(value+1);
		updateForm();
	}
	function minusSlots() {
		value = parseInt($('#slots').val());
		$('#slots').val(value-1);
		updateForm();
	}
	function plusSlots10() {
		value = parseInt($('#slots').val());
		$('#slots').val(value+10);
		updateForm();
	}
	function minusSlots10() {
		value = parseInt($('#slots').val());
		$('#slots').val(value-10);
		updateForm();
	}
	function makeRand(max){
		return Math.floor(Math.random() * max);
	}
	function generatePass(){
		var length = 12;
		var result = '';
		var symbols = new Array(
					'q','w','e','r','t','y','u','i','o','p',
					'a','s','d','f','g','h','j','k','l',
					'z','x','c','v','b','n','m',
					'Q','W','E','R','T','Y','U','I','O','P',
					'A','S','D','F','G','H','J','K','L',
					'Z','X','C','V','B','N','M',
					1,2,3,4,5,6,7,8,9,0
		);
		for (i = 0; i < length; i++){
			result += symbols[makeRand(symbols.length)];
		}
		document.getElementById('password').setAttribute('type', 'text');
		document.getElementById('password').value = result;
		document.getElementById('password2').setAttribute('type', 'text');
		document.getElementById('password2').value = result;
	}
</script>
<?php echo $footer ?>