<?php echo $header ?>
<div class="row">
	<?php include 'menu.php';?>
		<div class="col-md-12">
			<div class="content-box">
			<h3 class="content-box-header bg-default">Конфигурация</h3>
				<div class="content-box-wrapper">
					<div class="portlet light ">
					<div class="portlet-body" style="padding-top: 0px;">
					<center><h5 id="text"></h5></center>
						<div class="table-scrollable table-scrollable-borderless" style="margin-top: 0px !important;">
						    <?php
								 if($server['game_query'] == 'samp'):
								 $config = "server.cfg";
								 endif;
								 $cfg = file_get_contents('ftp://gs'.$server['server_id'].':'.$server['server_password'].'@'.$server['location_ip'].':21/'.$config.'');
								 if(isset($_REQUEST['otp'])){
								 $context = stream_context_create(array('ftp'=>array('overwrite' => true)));
								 $fopen=fopen('ftp://gs'.$server['server_id'].':'.$server['server_password'].'@'.$server['location_ip'].'/'.$config.'',"w",false,$context);
								 $fputs=fputs($fopen,$_REQUEST['txt']);
								 fclose($fopen);
								 }
							?>
							<form id="addForm" name=forma method='POST'>
								<textarea name=txt class="form-control" rows="20" wrap="off" onkeydown="TabText()"><?php echo $cfg ?></textarea>
								<br>
								<button type="submit" class="button1 primary" data-hover="Сохранить">Сохранить</button>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<script> 
   $(function(){ 
   $('#addForm').submit(function(e){ 
   e.preventDefault(); 
   var m_method=$(this).attr('method'); 
   var m_action=$(this).attr('action'); 
   var m_data=$(this).serialize(); 
   $.ajax({ 
   type: m_method, 
   url: m_action, 
   data: m_data, 
   success: function(result){ 
   $('#status').html(result); 
   $.jGrowl('</b> Конфигурация успешно сохранена!', { sticky: !1, position: "top-right", theme: "bg-green" });
   setTimeout("reload()", 2500);
   } 
   }); 
   }); 
   }); 
   $('#addForm').ajaxForm({ 
   beforeSubmit: function(arr, $form, options) { 
   $('button[type=submit]').prop('disabled', true); 
   } 
   }); 
</script>
<?php echo $footer ?>