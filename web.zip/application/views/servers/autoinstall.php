<?php echo $header ?>
<div class="row">
	<?php include 'menu.php';?>
		<div class="col-md-12"></div>
			<main id="main-container">
				<div class="block">
					<div class="col-md-12">
						<div class="content-box">
						<h3 class="content-box-header bg-default">Автоустановка модов</h3>
							<div class="content-box-wrapper" style="margin: 15px 0;">
         <?php foreach($auto as $item):  ?>
         <?php if($server['game_id'] == $item['game_id']): ?>
         <div class="col-lg-4">
            <div class="m-portlet m-portlet--brand m-portlet--head-solid-bg m-portlet--bordered">
               <div class="m-portlet__body">			   
                  <div class="m-demo" data-code-preview="true" data-code-html="true" data-code-js="false">
                     <div class="m-demo__preview" style="padding: 3px;">
                        <center><img src="<?php echo $item['auto_img'] ?>" style="max-width:100%;height:auto;" alt=""></center>
                     </div>
                  </div>
                  <center><strong><span style="font-size: x-large;"><?php echo $item['auto_name']?></span></strong></center>
                  <br>
                  <div class="m-scrollable m-scroller" data-scrollbar-shown="true" data-scrollable="true" data-height="100" style="overflow: auto; height: 70px;">
                     <?php echo $item['auto_textx']?>
                  </div>
                  <hr>
                  <?php if($item['auto_act'] == 2): ?>
                  <?php foreach($userautos as $auto):  ?>
                  <? if($auto['auto_id'] == $item['auto_id']) $item['free_autoe'] = 1; ?>
                  <?php endforeach; ?>
                  <? if($item['free_autoe'] == 1): ?>
                  <div class="kt-portlet__foot">
                     <div class="row align-items-center">
                        <div class="col-lg-6">
                           <button type="submit" onClick="sendAction(<?php echo $server['server_id'] ?>,'<?echo $item['auto_id']?>')" class="button1 info btn-block">Установить</button>
                        </div>
                        <div class="col-lg-6 kt-align-right">
                           <div class="button1 info btn-block">Куплено.</div>
                        </div>
                     </div>
                  </div>
                  <? else: ?>
                  <div class="kt-portlet__foot">
                     <div class="row align-items-center">
                        <div class="col-lg-6">
                           <button type="submit" onClick="sendAction(<?php echo $server['server_id'] ?>,'<?echo $item['auto_id']?>')" class="button1 info btn-block">Купить</button>
                        </div>
                        <div class="col-lg-6 kt-align-right">
                           <div class="button1 info btn-block">Цена <?php echo $item['auto_price']?> руб.</div>
                        </div>
                     </div>
                  </div>
                  <?php endif;?>
                  <?php elseif($item['auto_act'] == 1): ?>
                  <a href="#javascript" onClick="sendAction(<?php echo $server['server_id'] ?>,'<?echo $item['auto_id']?>')" class="button1 info btn-block">Установить</a>
                  <?php endif; ?>
               </div>
            </div>
         </div>
         <?php endif;?>	
         <?php endforeach; ?>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<script>	
function sendAction(serverid, action) {					
	$.ajax({ 
		url: '/servers/autoinstall/action/'+serverid+'/'+action,
		dataType: 'text',
		success: function(data) {
			console.log(data);
			data = $.parseJSON(data);
			switch(data.status) {
				case 'error':
					$.jGrowl(data.error, { sticky: !1, position: "top-right", theme: "bg-red" });
					$('#controlBtns button').prop('disabled', false);
					break;
				case 'success':
					$.jGrowl(data.success, { sticky: !1, position: "top-right", theme: "bg-green" });
					$('#controlBtns button').prop('disabled', false);
					setTimeout("location.replace('/servers/control/index/<?php echo $server['server_id'] ?>')", 1500);
					break;
				}
			},
			beforeSend: function(arr, options) {
				<?php foreach($auto as $item): ?> 
				if(action == "<?echo $item['auto_id']?>") $.jGrowl("Идет установка <?echo $item['auto_name']?>, пожалуйста подождите!", { sticky: !1, position: "top-right", theme: "bg-yellow" });
				<?endforeach;?>
				$('#controlBtns button').prop('disabled', true);
			}
		});
	}			
</script>
<?php echo $footer ?>