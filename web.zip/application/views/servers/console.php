<?echo $header?>
<div class="row">
<?php include 'menu.php';?>
<div class="col-lg-12">																							
<div class="portlet light">
<div class="portlet-title">
								<div class="caption">
		<h3 class="content-box-header bg-default">Консоль<label style="float:right;" data-toggle="tooltip" data-placement="top" title="Автообновление консоли каждые 15 секунд."><input type="checkbox" checked id="autoscroll"> Автообновление<span></span></label></h3>
								</div>
							</div>

<?php 
								if($_POST['cmd_console'] && $server['game_code'] == 'samp' || $_POST['cmd_console'] && $server['game_code'] == 'crmp'):
									require_once('./SampRconAPI.php');
									$cfg = file_get_contents('ftp://gs'.$server['server_id'].':'.$server['server_password'].'@'.$server['location_ip'].':21/server.cfg');
									$pass = explode("\n",$cfg);
									$pass = substr($pass[2], 14);
									$cmd = $_POST['cmd'];
									$server_cmd = new SampRconAPI($server['location_ip'],$server['server_port'], $pass);
									if($server_cmd->isOnline()) $result = $server_cmd->call($cmd);
									
									if(empty($result[0])):
										echo '<div class="alert alert-success"><b>Выполнено!</b> Команда <code>'.$cmd.'</code> отправлена</div>';
									endif;
								elseif($_POST['cmd_console'] && $server['game_query'] == 'valve'):
								// For the sake of this example
	require __DIR__ . '/SourceQuery/SourceQuery.class.php';
	// Edit this ->
	define( 'SQ_SERVER_ADDR', $server['location_ip'] );
	define( 'SQ_SERVER_PORT',  $server['server_port']  );
	define( 'SQ_TIMEOUT',     1 );
	define( 'SQ_ENGINE',       SourceQuery :: GOLDSOURCE );
	// Edit this <-
	
	$Query = new SourceQuery( );
	$cmd = $_POST['cmd'];
	try
	{
		$Query->Connect( SQ_SERVER_ADDR, SQ_SERVER_PORT, SQ_TIMEOUT, SQ_ENGINE );
		
		$Query->SetRconPassword( $server['rcon_password'] );
		
		$Query->Rcon( $cmd );
         		
	}
	catch( Exception $e )
 {
  echo $e->getMessage( );
 }
 $Query->Disconnect( );
 endif;
							?>
							<?if($server['rcon_password'] == NULL && $server['game_query'] == 'valve'):?>
<textarea id="textd" class="form-control" rows="15" style="color: #fff; background: #000; border: #000;"disabled="">Установите RCON-Пароль!</textarea>
<?elseif($server['server_status'] == 2):?>
<textarea id="textAreaObject" class="form-control" rows="15" style="color: #fff; background: #000; border: #000;" disabled="">Загрузка...</textarea>
<?elseif($server['server_status'] == 1):?>
<textarea id="textd" class="form-control" rows="15" style="color: #fff; background: #000; border: #000;"disabled="">Включите сервер!</textarea>
<?elseif($server['server_status'] == 0):?>
<textarea id="textd" class="form-control" rows="15" style="color: #fff; background: #000; border: #000;"disabled="">Сервер не оплачен!</textarea>
<?endif;?>

							<br>
							<form class="form-inline" role="form" method='POST' id="form_pr" action="" >
							  <div class="form-group" style="width: 50%;">
								<input style="width: 100%;" type="text" class="form-control" name="cmd" placeholder="Введите команду">
							  </div>
							  <div class="form-group">
								  <input type="hidden" name="cmd_console" value="true">
								  <?if($server['game_query'] == 'samp'):?><a href="#" data-toggle="modal" data-target="#infoCMD" class="button1 info">Доступные команды</a>
									<button class="button1 xeon" type="sumbit" id="send">Отправить</button></br>
								  <?elseif($server['game_query'] == 'valve'):?><a href="#" data-toggle="modal" data-target="#rpass" class="btn btn-info">Установить RCON-Пароль</a><?endif;?>
								 
							  </div> 
							</form>
					    <form class="form-inline" role="form" method='POST' id="clearform" action="" >
						<button type="submit" data-container="body" data-toggle="m-popover" data-placement="top" data-content="Очистить консоль" data-original-title="" title="" class="button1 ramil btn-block sbold uppercase">Очистить консоль</button>
					</form>
				<hr>				
						  </div>
						</div>
						<br><br>
					</div>
				</div>
								<div class="modal fade" id="rpass" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
				  <div class="modal-dialog">
					<div class="modal-content">
					  <div class="modal-header">
						<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
						<h4 class="modal-title" id="myModalLabel">Установить rcon</h4>
					  </div>
					  <div class="modal-body">
					  <form class="form-horizontal" action="#" id="rconForm" method="POST">
<div class="form-group">
							<label for="ammount" class="col-sm-3 control-label">Ркон:</label>
<div class="input-group">
								<input type="text" class="form-control" id="rcon" name="rcon">
							</div>
						</div>
						<input type="submit" class="btn btn-danger  btn-block" value="Сохранить">
						</form>
					  </div>
					</div>
				  </div>
				</div>
				<div class="modal fade" id="infoCMD" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
				  <div class="modal-dialog">
					<div class="modal-content">
					  <div class="modal-header">
						<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
						<h4 class="modal-title" id="myModalLabel">Доступные команды</h4>
					  </div>
					  <div class="modal-body">
						<code>cmdlist</code> - Показать список RCON команд<br>
						<code>varlist</code> - Посмотреть список текущих настроек<br>
						<code>kick [ID]</code> - Кикнуть пользователя по его ID (Пример: kick 3)<br>
						<code>ban [ID]</code> - Забанить пользователя по его ID (Пример: ban 3)<br>
						<code>banip [IP]</code> - Забанить IP (Пример: banip 127.0.0.1)<br>
						<code>unbanip [IP]</code> - Разбанить IP (Пример: unbanip 127.0.0.1)<br>
						<code>reloadbans</code> - Перезагрузить samp.ban, в котором содержатся забаненные IP<br>
						<code>reloadlog</code> - Очистить лог сервера<br>
						<code>exec [имя файла]</code> - Открыть файл .cfg (Пример: exec blah.cfg)<br>
						<code>say [текст]</code> - Сказать в общий чат от лица админа (Пример: say Hello)<br>
						<code>players</code> - Показать всех игроков на сервере с их именами, ip и пингом<br>
						<code>gravity</code> - Изменить гравитацию на сервере - (Пример: gravity 0.008)<br>
						<code>weather [ID]</code> - Изменить погоду на сервере (Пример: weather 2)<br>
						<code>worldtime [время]</code> - Изменить время на сервере (Пример: worldtime 2)<br>
						<code>maxplayers</code> - Изменить макс. количество мест на сервере<br>
						<code>timestamp</code> - Установить часовой пояс<br>
						<code>plugins</code> - Посмотреть список всех установленных плагинов<br>
						<code>filterscripts</code> - Посмотреть список всех установленных фильтрскриптов<br>
						<code>loadfs [название]</code> - Загрузить фильтрскрипт<br>
						<code>unloadfs [название]</code> - Выгрузить фильтрскрипт<br>
						<code>reloadfs [название]</code> - Перезагрузить фильтрскрипт<br>
						<code>password [пароль]</code> - Установить пароль на сервере<br>
						<code>changemode [название]</code> - Изменить режим игры на сервере на заданный<br>
						<code>gmx</code> - Рестарт сервера<br>
						<code>hostname [название]</code> - Изменить название сервера<br>
						<code>gamemodetext [название]</code> - Изменить название мода<br>
						<code>mapname [название]</code> - Изменить название карты<br>
						<code>gamemode [1-15]</code> - Установить порядок гэйм-модов<br>
						<code>instagib [bool]</code> - Включить функцию убийства с одной пули (1 или 0)<br>
						<code>lanmode [bool]</code> - Установить LAN (1 или 0)<br>
						<code>version</code> - Посмотреть версию сервера<br>
						<code>weburl [урл]</code> - Установить url сайта на сервере<br>
					  </div>
					</div>
				  </div>
				</div>
 
					<script type="text/javascript">                      
					$('#rconForm').ajaxForm({ 
						url: '/servers/console/ajax/<?php echo $server['server_id'] ?>',
						dataType: 'text',
						success: function(data) {
							console.log(data);
							data = $.parseJSON(data);
							switch(data.status) {
								case 'error':
									toastr.error(data.error);
									$('button[type=submit]').prop('disabled', false);
									break;
								case 'success':
									toastr.success(data.success);
									break;
							}
						},
						beforeSubmit: function(arr, $form, options) {
							$('button[type=submit]').prop('disabled', true);
						}
					});                                                                                                       
					<!--                                                                                                                                                         

							 function updatelog() {
							var serverid = '<?=$server['server_id']?>';
							var locationid = '<?=$server['location_id']?>';
							var autoscroll = document.getElementById("autoscroll");
								if (autoscroll.checked==false)
							{
								setTimeout(updatelog,1000);
							return;
							}
							<?if($server['game_query'] == 'samp'):?>
							$.get("/console.php?action=getconsole",{serverid: serverid , locationid: locationid} )
							<?elseif($server['game_query'] == 'valve'):?>
							$.get("/console.php?action=getconsoles",{serverid: serverid , locationid: locationid} )
							<?elseif($server['game_query'] == 'mine'):?>
							$.get("/servers/console/getconsole/"+serverid)							
							<?endif;?>
					
								.done(function(data) {
							displayconsole(serverid,data);
							setTimeout(updatelog,1000);
							});
							 }
							function displayconsole(serverid,sText) {
								var divInfo = document.getElementById("textAreaObject");
								console.log(sText);
								divInfo.innerHTML =  sText;
								divInfo.scrollTop = divInfo.scrollHeight;
								return;
							}

					$(document).ready(function() {
						updatelog();
					});
					//-->
					</script>
					<script type="text/javascript">
$(function(){
$('#clearform').submit(function(e){
//отменяем стандартное действие при отправке формы
e.preventDefault();
//берем из формы метод передачи данных
var m_method=$(this).attr('method');
//получаем адрес скрипта на сервере, куда нужно отправить форму
var m_action=$(this).attr('action');
//получаем данные, введенные пользователем в формате input1=value1&input2=value2...,то есть в стандартном формате передачи данных формы
var m_data=$(this).serialize();
$.ajax({
type: m_method,
url: m_action,
data: m_data,
url: '/servers/console/clearcon/<?php echo $server['server_id'] ?>',
success: function(result){
	console.log(result);
$('#status').html(result);
<?if($server['rcon_password'] == NULL && $server['game_query'] == 'valve'):?>
toastr.error('Ошибка #R3: </b> Установите ркон пароль!');
<?elseif($server['server_status'] == 2):?>
toastr.success('</b> Консоль успешно очищена!');
<?elseif($server['server_status'] == 1):?>
toastr.error('Ошибка #R1: </b> Сервер должен быть включен!');
<?elseif($server['server_status'] == 0):?>
toastr.error('Ошибка #R2: </b> Оплатите ваш сервер!');
<?endif;?>
}
});
});
});
</script>
<script type="text/javascript">
$(function(){
$('#form_pr').submit(function(e){
//отменяем стандартное действие при отправке формы
e.preventDefault();
//берем из формы метод передачи данных
var m_method=$(this).attr('method');
//получаем адрес скрипта на сервере, куда нужно отправить форму
var m_action=$(this).attr('action');
//получаем данные, введенные пользователем в формате input1=value1&input2=value2...,то есть в стандартном формате передачи данных формы
var m_data=$(this).serialize();
if('<?php echo $server['game_query'] ?>' == 'mine'){
	$.post("/servers/console/sendconsole/<?php echo $server['server_id']  ?>?"+m_data,
	function(data){
		data = $.parseJSON(data);
		switch(data.status) {
			case 'error':
				toastr.error('Не удалось отправить команду на сервер');
				break;
			case 'success':
				$('#cmd').val('');
				toastr.success('</b> Команда успешно отправлена');
				break;
			}
		});
	return true;
}

$.ajax({
type: m_method,
url: m_action,
data: m_data,
success: function(result){
$('#status').html(result);
<?if($server['rcon_password'] == NULL && $server['game_query'] == 'valve'):?>
toastr.error('Ошибка #R3: </b> Установите ркон пароль!');
<?elseif($server['server_status'] == 2):?>
toastr.success('</b> Команда успешно отправлена!');
<?elseif($server['server_status'] == 1):?>
toastr.error('Ошибка #R1: </b> Сервер должен быть включен!');
<?elseif($server['server_status'] == 0):?>
toastr.error('Ошибка #R2: </b> Оплатите ваш сервер!');
<?endif;?>
}
});
});
});
</script>
<?echo $footer?>