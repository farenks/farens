<div class="col-md-12">
	<div class="remove-border dashboard-buttons clearfix">
		<a href="/servers/control/index/<?php echo $server['server_id'] ?>" class="btn vertical-button remove-border btn-warning">
			<span class="glyph-icon icon-separator-vertical"><i class="glyph-icon icon-desktop"></i></span>
			<span class="button-content">Сервер</span>
		</a>
		<a href="/servers/ftp/index/<?php echo $server['server_id'] ?>" class="btn vertical-button remove-border btn-purple">
			<span class="glyph-icon icon-separator-vertical"><i class="glyph-icon icon-file"></i></span>
			<span class="button-content">FTP</span>
		</a>
		<a href="/servers/mysql/index/<?php echo $server['server_id'] ?>" class="btn vertical-button remove-border btn-yellow">
			<span class="glyph-icon icon-separator-vertical"><i class="glyph-icon icon-database"></i></span>
			<span class="button-content">MySQL</span>
		</a>
		<a href="/servers/serverLogs/index/<?php echo $server['server_id'] ?>" class="btn vertical-button remove-border btn-success">
			<span class="glyph-icon icon-separator-vertical"><i class="glyph-icon icon-file-text-o"></i></span>
			<span class="button-content">Логи</span>
		</a>
		<a href="/servers/config/index/<?php echo $server['server_id'] ?>" class="btn vertical-button remove-border btn-blue-alt">
			<span class="glyph-icon icon-separator-vertical"><i class="glyph-icon icon-file-code-o"></i></span>
			<span class="button-content">Конфигурация</span>
		</a>
		<a href="/servers/console/index/<?php echo $server['server_id'] ?>" class="btn vertical-button remove-border btn-info">
			<span class="glyph-icon icon-separator-vertical"><i class="glyph-icon icon-barcode"></i></span>
			<span class="button-content">Консоль</span>
		</a>
		<a href="/servers/autoinstall/index/<?php echo $server['server_id'] ?>" class="btn vertical-button remove-border btn-warning">
			<span class="glyph-icon icon-separator-vertical"><i class="glyph-icon icon-file-text-o"></i></span>
			<span class="button-content">Автоустановка</span>
		</a>
	</div>
</div>