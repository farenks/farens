<?php echo $header ?>
<div class="row">
	<div class="col-md-12">
		<div class="content-box">
			<h3 class="content-box-header bg-default">Мои сервера</h3>
			<div class="content-box-wrapper">
				<table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered">
					<thead>
						<tr>
							<th>ID</th>
							<th>Статус</th>
							<th>Игра</th>
							<th>Локация</th>
							<th>IP</th>
							<th>Действия</th>
						</tr>
					</thead>
					<tbody>
						<?php foreach($servers as $item): ?>
						<tr>
							<td>#<?php echo $item['server_id'] ?></td>
							<td>
								<?php if($item['server_status'] == 0): ?>
								<span class="bs-label label-warning">Заблокирован</span>
								<?php elseif($item['server_status'] == 1): ?>
								<span class="bs-label label-danger">Выключен</span>
								<?php elseif($item['server_status'] == 2): ?>
								<span class="bs-label label-success">Включен</span>
								<?php elseif($item['server_status'] == 3): ?>
								<span class="bs-label label-warning">Установка</span>
								<?php endif; ?>
							</td>
							<td><?php echo $item['game_name'] ?></td>
							<td><?php echo $item['location_name'] ?></td>
							<td><?php echo $item['location_ip'] ?>:<?php echo $item['server_port'] ?></td>
							<td><button type="button" class="btn btn-xs bg-purple" onClick="redirect('/servers/control/index/<?php echo $item['server_id'] ?>')">Перейти в панель управления</button></td>
						</tr>
						<?php endforeach; ?>
						<?php if(empty($servers)): ?>
						<tr>
							<td colspan="6" style="text-align: center;">На данный момент у вас нет серверов.</td>
						<tr>
						<?php endif; ?>
					</tbody>
				</table>
			</div>
			<ul class="pagination pull-right">
				<?php echo $pagination ?>
			</ul>
		</div>
	</div>
</div>
<?php echo $footer ?>