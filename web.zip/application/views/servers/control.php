<?php echo $header ?>
<div class="row">
	<?php include "menu.php";?><br>
	<div class="col-md-6">
		<div class="content-box">
			<h3 class="content-box-header bg-default">Управление сервером #<?php echo $server['server_id'] ?></h3>
			<div class="content-box-wrapper">
				<table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered">
					<tbody>
						<tr>
							<th>Статус:</th>
							<td>
								<?php if($server['server_status'] == 0): ?>
								<span class="bs-label label-warning">Заблокирован</span>
								<?php elseif($server['server_status'] == 1): ?>
								<span class="bs-label label-danger">Выключен</span>
								<?php elseif($server['server_status'] == 2): ?>
								<span class="bs-label label-success">Включен</span>
								<?php elseif($server['server_status'] == 3): ?>
								<span class="bs-label label-warning">Установка</span>
								<?php elseif($server['server_status'] == 4): ?>
								<span class="bs-label label-black">Заблокирован администратором</span>
								<?php endif; ?>
							</td>
						</tr>
						<tr>
							<th>ID сервера:</th>
							<td>#<?php echo $server['server_id'] ?></td>
						</tr>						
						<tr>
							<th>Игра:</th>
							<td><?php echo $server['game_name'] ?></td>
						</tr>
						<tr>
							<th>Локация:</th>
							<td><?php echo $server['location_name'] ?></td>
						</tr>
						<tr>
							<th>Адрес:</th>
							<td><?php echo $server['location_ip'] ?>:<?php echo $server['server_port'] ?><a data-toggle="modal" data-target="#BuyPort" style="cursor:pointer; float:right;"><button class="button1 btn-purple"><i class="glyph-icon icon-shopping-cart"></i><div class="ripple-wrapper"></div></button></a></td>
						</tr>
						<tr>
							<th>Слоты:</th>
							<td><?php echo $server['server_slots'] ?><a data-toggle="modal" data-target="#BuySlots" style="cursor:pointer; float:right;"><button class="button1 btn-purple"><i class="glyph-icon icon-shopping-cart"></i><div class="ripple-wrapper"></div></button></a></td>
						</tr>
						<tr>
							<th>Дата окончания оплаты:</th>
							<td><?php echo date("d.m.Y", strtotime($server['server_date_end'])) ?><a href="/servers/pay/index/<?php echo $server['server_id'] ?>" style="cursor:pointer; float:right;"><button class="button1 btn-purple">Продлить<div class="ripple-wrapper"></div></button></a></td>
						</tr>
					</tbody>
				</table>
			</div>
		</div>
		<?php if($server['server_status'] == 1): ?>
		<button type="button" class="button1 success" data-hover="Включить" onClick="sendAction(<?php echo $server['server_id'] ?>,'start')">Включить</button>
		<button type="button" class="button1 warning" data-hover="Переустановить" onClick="sendAction(<?php echo $server['server_id'] ?>,'reinstall')">Переустановить</button>
		<button type="button" class="button1 primary" data-hover="Сделать BackUP" onClick="sendAction(<?php echo $server['server_id'] ?>,'backup')">Сделать BackUP</button>
		<button type="button" class="button1 info" data-hover="Развернуть BackUP" onClick="sendAction(<?php echo $server['server_id'] ?>,'unbackup')">Развернуть BackUP</button>
		<?php elseif($server['server_status'] == 2): ?>
		<button type="button" class="button1 danger" data-hover="Выключить" onClick="sendAction(<?php echo $server['server_id'] ?>,'stop')">Выключить</button>
		<button type="button" class="button1 info" data-hover="Перезапустить" onClick="sendAction(<?php echo $server['server_id'] ?>,'restart')">Перезапустить</button>
		<?php endif; ?>
	</div>
	<div class="col-md-6">
		<div class="content-box">
			<h3 class="content-box-header bg-default">Статистика сервера #<?php echo $server['server_id'] ?></h3>
			<div class="content-box-wrapper">
				<table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered">
					<tbody>
					<?php if($server['server_status'] == 2): ?>
						<?php if($query): ?> 
								<tr>
									<th>Название:</th>
									<td><?php echo $query['hostname'] ?></td>
								</tr>
								<tr>
									<th>Игроки:</th>
									<td><?php echo $query['players'] ?> из <?php echo $query['maxplayers'] ?></td>
								</tr>
								<tr>
									<th>Игровой режим:</th>
									<td><?php echo $query['gamemode'] ?></td>
								</tr>
								<tr>
									<th>Карта:</th>
									<td><?php if($server['game_code'] == 'samp') { echo 'San Andreas';} elseif($server['game_code'] == 'mtasa') { echo 'San Andreas';} else {echo $query['mapname']; }?></td>
								</tr>
								<tr>
									<th>Нагрузка RAM</th>
									<td>Частота обновления 5 минут</td>
								</tr>
								<tr>
									<th>Нагрузка CPU</th>
									<td>Частота обновления 1 час</td>
								</tr>
						<?php endif; ?>
						<?php elseif($server['server_status'] == 1): ?>
					<div class="content-box">
								<div class="content-box-wrapper">
									Статистика сервера показывается только тогда, когда сервер включен!
								</div>
							</div>
						<?php endif; ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>

<div class="modal fade in" id="BuyPort" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="false" style="display: none;">
	<div style="width: 400px; top: 160px;" class="modal-dialog">
		<div class="modal-content">
			<form class="form-horizontal" action="#" id="portForm" method="POST">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
					<h4 class="modal-title">Изменение порта</h4>
				</div>
				<div class="modal-body">
					<div class="input-group">
						<select class="form-control" name="port">
							<?php foreach($gameServerPorts as $item): ?>
							<option value="<?php echo $item ?>"><?php echo $item ?></option>
							<?php endforeach; ?>
							<?php if(empty($gameServerPorts)): ?>
							<option value="null">На данный момент нет свободных портов.</option>
							<?php endif; ?>
						</select>
                    </div>
					<div class="input-group" style="font-size:19px">
						<p class="lead"><span id="price_port"></span><?php echo $portPrice ?> руб.</p>
					</div>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">Закрыть</button>
					<button type="submit" class="btn btn-primary">Оплатить<div class="ripple-wrapper"></div></button>
				</div>
			</form>
		</div>
	</div>
</div>

<div class="modal fade in" id="BuySlots" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="false" style="display: none;">
	<div style="width: 400px; top: 160px;" class="modal-dialog">
		<div class="modal-content">
			<form class="form-horizontal" action="#" id="edit_slots" method="POST">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
					<h4 class="modal-title">Изменение слотов</h4>
				</div>
				<div class="modal-body">
					<div class="input-group" onkeyup="updateForm(true)">
						<span class="input-group-btn"><button class="btn btn-primary" type="button" onClick="minusSlots10()"><<</button></span>
						<span class="input-group-btn"><button class="btn btn-default" type="button" onClick="minusSlots()">-</button></span>
						<input type="text" class="form-control" id="slots" name="slots" value="<?echo $server['server_slots']?>">
						<span class="input-group-btn"><button class="btn btn-default" type="button" onClick="plusSlots()">+</button></span>
						<span class="input-group-btn"><button class="btn btn-success" type="button" onClick="plusSlots10()">>></button></span>
					</div>
					<div class="input-group" style="font-size:19px">
						<p class="lead"><span id="price"></span></p>
					</div>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">Закрыть</button>
					<button type="submit" class="btn btn-primary">Оплатить<div class="ripple-wrapper"></div></button>
				</div>
			</form>
		</div>
	</div>
</div>

<script>
    $('#portForm').ajaxForm({ 
		url: '/servers/control/ajax_port/<?php echo $server['server_id'] ?>',
		dataType: 'text',
		success: function(data) {
			console.log(data);
			data = $.parseJSON(data);
			switch(data.status) {
				case 'error':
					$.jGrowl(data.error, { sticky: !1, position: "top-right", theme: "bg-red" });
					$('button[type=submit]').prop('disabled', false);
					break;
				case 'success':
					$.jGrowl(data.success, { sticky: !1, position: "top-right", theme: "bg-green" });
					setTimeout("reload()",1000);
					break;
			}
		},
		beforeSubmit: function(arr, $form, options) {
			$('button[type=submit]').prop('disabled', true);
		}
    });
	
    $('#edit_slots').ajaxForm({ 
		url: '/servers/control/ajax_slots/<?php echo $server['server_id'] ?>',
		dataType: 'text',
		success: function(data) {
			console.log(data);
			data = $.parseJSON(data);
			switch(data.status) {
				case 'error':
					$.jGrowl(data.error, { sticky: !1, position: "top-right", theme: "bg-red" });
					$('button[type=submit]').prop('disabled', false);
					break;
				case 'success':
					$.jGrowl(data.success, { sticky: !1, position: "top-right", theme: "bg-green" });
					setTimeout("reload()",1000);
					break;
			}
		},
		beforeSubmit: function(arr, $form, options) {
			$('button[type=submit]').prop('disabled', true);
		}
	});
	
    $(document).ready(function() {
		updateForm();
    });
	
    function updateForm(promo) {
    var gamePrice = <?=$server['game_price']?>;
    var gameMax = <?=$server['game_max_slots']?>;
    var sslots = <?=$server['server_slots']?>;
    var slots = $("#slots").val();
    if(slots < sslots) {
        slots = sslots;
        $("#slots").val(slots);
    }
    else if(slots > gameMax) {
        slots = gameMax;
        $("#slots").val(slots);
    }
    var price = gamePrice * (slots-sslots);
        $('#price').text(price.toFixed(2) + ' руб.');
    }
   
	function plusSlots() {
		value = parseInt($('#slots').val());
		$('#slots').val(value+1);
		updateForm();
	}
	function minusSlots() {
		value = parseInt($('#slots').val());
		$('#slots').val(value-1);
		updateForm();
	}
	function plusSlots10() {
		value = parseInt($('#slots').val());
		$('#slots').val(value+10);
		updateForm();
	}
	function minusSlots10() {
		value = parseInt($('#slots').val());
		$('#slots').val(value-10);
		updateForm();
	}

	function sendAction(serverid, action) {
		switch(action) {
			case "reinstall":
			{
				if(!confirm("Вы уверенны в том, что хотите переустановить сервер? Все данные будут удалены.")) return;
				break;
			}
			case "backup":
			{
				if(!confirm("Вы уверены в том, что хотите сделать бэкап сервера? Прежний бэкап будет удален.")) return;
				break;
			}
			case "unbackup":
			{
				if(!confirm("Вы уверены в том, что хотите восстановить сервер?")) return;
				break;
			}
		}
		$.ajax({ 
			url: '/servers/control/action/'+serverid+'/'+action,
			dataType: 'text',
			success: function(data) {
				console.log(data);
				data = $.parseJSON(data);
				switch(data.status) {
					case 'error':
						//showError(data.error);
						$.jGrowl(data.error, { sticky: !1, position: "top-right", theme: "bg-red" });
						$('#controlBtns button').prop('disabled', false);
						break;
					case 'success':
						//showSuccess(data.success);
						$.jGrowl(data.success, { sticky: !1, position: "top-right", theme: "bg-green" });
						setTimeout("reload()", 1500);
						break;
				}
			},
			beforeSend: function(arr, options) {
				if(action == "reinstall") $.jGrowl("Сервер будет переустановлен в течении 10 секунд!", { sticky: !1, position: "top-right", theme: "bg-yellow" });
				if(action == "backup") $.jGrowl("Создается BackUp Сервера! Пожалуйста, подождите некоторое время.", { sticky: !1, position: "top-right", theme: "bg-yellow" });
				if(action == "unbackup") $.jGrowl("Сервер восстанавливается! Пожалуйста, подождите некоторое время.", { sticky: !1, position: "top-right", theme: "bg-yellow" });
				if(action == "stop") $.jGrowl("Сервер выключится через 10 секунд! Пожалуйста, подождите.", { sticky: !1, position: "top-right", theme: "bg-yellow" });
				if(action == "start") $.jGrowl("Сервер запускается! Пожалуйста, подождите некоторое время.", { sticky: !1, position: "top-right", theme: "bg-yellow" });
				if(action == "restart") $.jGrowl("Сервер перезапускается! Пожалуйста, подождите некоторое время.", { sticky: !1, position: "top-right", theme: "bg-yellow" });
				$('#controlBtns button').prop('disabled', true);
			}
		});
	}
</script>
<?php echo $footer ?>