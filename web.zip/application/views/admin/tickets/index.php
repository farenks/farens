<?php echo $admheader ?>
<div class="row">
	<div class="col-md-12">
		<div class="content-box">
			<h3 class="content-box-header bg-default">Все запросы</h3>
			<div class="content-box-wrapper">
				<table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered">
					<thead>
						<tr>
							<th>ID</th>
							<th>Статус</th>
							<th>Тема</th>
							<th>Пользователь</th>
							<th>Дата создания</th>
							<th>Действия</th>
						</tr>
					</thead>
					<tbody>
						<?php foreach($tickets as $item): ?>
						<tr>
							<td>#<?php echo $item['ticket_id'] ?></td>
							<td>
								<?php if($item['ticket_status'] == 0): ?>
								<span class="bs-label label-danger">Закрыт</span>
								<?php elseif($item['ticket_status'] == 1): ?>
								<span class="bs-label label-success">Открыт</span>
								<?php endif; ?> 
							</td>
							<td><?php echo $item['ticket_name'] ?></td>
							<td><?php echo $item['user_firstname'] ?> <?php echo $item['user_lastname'] ?></td>
							<td><?php echo date("d.m.Y в H:i", strtotime($item['ticket_date_add'])) ?></td>
							<td><button type="button" class="btn btn-xs bg-purple" onClick="redirect('/admin/tickets/view/index/<?php echo $item['ticket_id'] ?>')">Перейти к запросу</button></td>
						</tr>
						<?php endforeach; ?>
						<?php if(empty($tickets)): ?>
						<tr>
							<td colspan="6" style="text-align: center;">На данный момент нет запросов в службу поддержки.</td>
						<tr>
						<?php endif; ?>
					</tbody>
				</table>
			</div>
			<ul class="pagination pull-right">
				<?php echo $pagination ?>
			</ul>
		</div>
	</div>
</div>
<?php echo $footer ?>