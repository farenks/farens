<?php echo $admheader ?>
<div class="row">
	<div class="col-md-12">
		<div class="content-box">
			<h3 class="content-box-header bg-default">Список модов</h3>			
			<div class="content-box-wrapper">
				<table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered">
					<thead>
						<tr>
							<th>№</th>
							<th>Игра</th>						
							<th>Название</th>
							<th>Статус</th>
							<th>Стоимость</th>
						</tr>
					</thead>
                  <tbody>
                     <?php foreach($auto as $item): ?>
                     <tr onClick="redirect('/admin/auto/edit/index/<?php echo $item['auto_id'] ?>')">
                        <th scope="row"><?php echo $item['auto_id'] ?></th>
                        <td><?php echo $item['game_name'] ?></td>
                        <td><?php echo $item['auto_name'] ?></td>
                        <td>
                           <?php if($item['auto_status'] == 0): ?> 
                           <span class="badge badge-danger">Выключен</span>
                           <?php elseif($item['auto_status'] == 1): ?> 
                           <span class="badge badge-success">Включен</span>
                           <?php endif; ?>
                        </td>
                        <td><?php echo $item['auto_price'] ?></td>
                     </tr>
                     <?php endforeach; ?>
                     <?php if(empty($auto)): ?> 
                     <tr>
                        <td colspan="5" class="text-center">На данный момент нет модов.</td>
                     </tr>
                     <?php endif; ?> 
                  </tbody>
				</table>
			</div>
			<ul class="pagination pull-right">
				<?php echo $pagination ?>
			</ul>
		</div>
	</div>
</div>
<?php echo $footer ?>