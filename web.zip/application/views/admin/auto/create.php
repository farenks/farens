<?php echo $admheader ?>
<div class="row">
	<div class="col-md-12">
		<div class="content-box">
			<h3 class="content-box-header bg-default">Создание мода</h3>
			<div class="content-box-wrapper">
        <form class="form-group form-md-line-input" action="#" id="createForm" method="POST">
            <div class="form-group form-md-line-input">
                <input type="text" class="form-control" id="name" name="name" placeholder="Введите название дополнения">
            </div>
            <div class="form-group form-md-line-input">
                <textarea class="form-control" id="textx" name="textx" rows="3" placeholder="Описание..."></textarea>
            </div>
            <div class="form-group form-md-line-input">
                <input type="text" class="form-control" id="img" name="img" placeholder="Введите ссылку на изображение">
            </div>
            <div class="form-group form-md-line-input">
                <select class="form-control" id="gameid" name="gameid" aria-required="true" aria-invalid="false" aria-describedby="delivery-error">
                    <?php foreach($games as $item): ?> 
                        <option value="<?php echo $item['game_id'] ?>"><?php echo $item['game_name'] ?></option>
                    <?php endforeach; ?> 
                </select>
            </div>
            <div class="form-group form-md-line-input">
                <input type="text" class="form-control" id="url" name="url" value="<?php echo $mod['mod_url'] ?>" placeholder="Введите ссылку на архив (zip)">
            </div>
            <div class="form-group form-md-line-input">
                <input type="text" class="form-control" id="arch" name="arch" value="<?php echo $mod['mod_arch'] ?>" placeholder="Введите название архива">
             </div>
            <div class="m-form__group form-group">
                <label class="m-checkbox m-checkbox--bold m-checkbox--state-brand">
                    <input type="checkbox" class="md-check" id="act" name="act" onChange="toggleBuy()"> Установить стоимость
                    <span></span>
                </label>
            </div>
            <div class="form-group form-md-line-input">
                <input type="text" class="form-control" id="price" name="price" placeholder="Введите стоимость дополнения" disabled>
            </div>
			<hr>
			<input type="submit" class="button1 primary" value="Сохранить">
        </form>
			</div>
		</div>
</div>
</div>
<script>
$('#createForm').ajaxForm({ 
	url: '/admin/auto/create/ajax',
	dataType: 'text',
	success: function(data) {
		console.log(data);
		data = $.parseJSON(data);
			switch(data.status) {
				case 'error':
					//showError(data.error);
					swal("Ошибка", data.error, "error");
					//$.jGrowl(data.error, { sticky: !1, position: "top-right", theme: "bg-red" });
					$('button[type=submit]').prop('disabled', false);
					break;
				case 'success':
					//showSuccess(data.success);
					swal("Успешно", data.success, "success");
					//$.jGrowl(data.success, { sticky: !1, position: "top-right", theme: "bg-green" });
					if(data.url){
						//setTimeout("redirect("+data.url+")", 1500);
						setTimeout("redirect('/admin/auto/')", 1500);
					}else{
						setTimeout("redirect('/admin/auto/')", 1500);
					}
					//setTimeout("redirect('/')", 1500);
					break;
			}
	},
	beforeSubmit: function(arr, $form, options) {
		$('button[type=submit]').prop('disabled', true);
	}
});
function toggleBuy() {
	var status = $('#act').is(':checked');
	if(status) {
		$('#price').prop('disabled', false);
	} else {
		$('#price').prop('disabled', true);
	}
}

$(function(){
  var progressBar = $('#progressbar');
  $('#createForm').on('submit', function(e){
    e.preventDefault();
    var $that = $(this),
        formData = new FormData($that.get(0));
    $.ajax({
      url: $that.attr('action'),
      type: $that.attr('method'),
      contentType: false,
      processData: false,
      data: formData,
      dataType: 'json',
      xhr: function(){
        var xhr = $.ajaxSettings.xhr();
        xhr.upload.addEventListener('progress', function(evt){
          if(evt.lengthComputable) {
            var percentComplete = Math.ceil(evt.loaded / evt.total * 100);
            progressBar.val(percentComplete).text('Загружено ' + percentComplete + '%');
			toastr.info('Загружено ' + percentComplete + '%');
          }
        }, false);
        return xhr;
      },
      success: function(json){
        if(json){
          $that.after(json);
        }
      }
    });
  });
});
</script>
<?php echo $footer ?>