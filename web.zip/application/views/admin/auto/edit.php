<?php echo $admheader ?>
<div class="row">
	<div class="col-md-12">
		<div class="content-box">
			<h3 class="content-box-header bg-default">Редактирование мода</h3>
      <div class="content-box-wrapper">
        <form class="form-group form-md-line-input" action="#" id="editForm" method="POST">
            <div class="form-group form-md-line-input">
                <input type="text" class="form-control" id="name" name="name" value="<?php echo $auto['auto_name'] ?>" placeholder="Введите название мода">
            </div>
            <div class="form-group form-md-line-input">
                <textarea class="form-control" id="textx" name="textx" rows="3"placeholder="Описание..."><?php echo $auto['auto_textx'] ?></textarea>
            </div>
            <div class="form-group form-md-line-input">
                <input type="text" class="form-control" id="img" name="img" value="<?php echo $auto['auto_img'] ?>" placeholder="Введите ссылку на изображение">
            </div>
			<div class="form-group form-md-line-input">
				<select class="form-control" id="gameid" name="gameid" aria-required="true" aria-invalid="false" aria-describedby="delivery-error">
				   <?php foreach($games as $item): ?> 
				   <option value="<?php echo $item['game_id'] ?>"><?php echo $item['game_name'] ?></option>
				   <?php endforeach; ?> 
				</select>
			</div>
            <div class="form-group form-md-line-input">
                <input type="text" class="form-control" id="url" name="url" value="<?php echo $auto['auto_url'] ?>" placeholder="Введите ссылку на архив (zip)">
            </div>
            <div class="form-group form-md-line-input">
                <input type="text" class="form-control" id="arch" name="arch" value="<?php echo $auto['auto_arch'] ?>" placeholder="Введите название архива">
             </div>
            <hr>
            <div class="m-form__group form-group">
                <label class="m-checkbox m-checkbox--bold m-checkbox--state-brand">
                    <input type="checkbox" class="md-check" id="act" name="act" onChange="toggleBuy()"> Установить стоимость
                    <span></span>
                </label>
            </div>
            <div class="form-group form-md-line-input">
                <input type="text" class="form-control" id="price" name="price" value="<?php echo $auto['auto_price'] ?>" placeholder="Введите стоимость мода" disabled>
            </div>
            <div class="form-group form-md-line-input">
                <select class="form-control" id="status" name="status" aria-required="true" aria-invalid="false" aria-describedby="delivery-error">
					<option value="0"<?php if($auto['auto_status'] == 0): ?> selected="selected"<?php endif; ?>>Выключен</option>
					<option value="1"<?php if($auto['auto_status'] == 1): ?> selected="selected"<?php endif; ?>>Включен</option>
                </select>
            </div>
			<hr>
			 <div class="m-btn-group m-btn-group--pill btn-group m-btn-group m-btn-group--pill btn-block" role="group" aria-label="Large button group">
				<button type="submit" class="button1 primary">Сохранить изменения</button>
				<a data-toggle="kt-tooltip" data-placement="right" title="" data-original-title="Удалить" style="height: 3.1rem;" href="/admin/auto/edit/delete/<?php echo $auto['auto_id'] ?>" class="button1 primary"><i class="fa fa-trash-alt">Удалить мод</i></a>
			 </div>
        </form>
      </div>			
		</div>
	</div>
</div>
<script>
   $('#editForm').ajaxForm({ 
   	url: '/admin/auto/edit/ajax/<?php echo $auto['auto_id'] ?>',
   	dataType: 'text',
   	success: function(data) {
   		console.log(data);
   		data = $.parseJSON(data);
			switch(data.status) {
				case 'error':
					//showError(data.error);
					swal("Ошибка", data.error, "error");
					//$.jGrowl(data.error, { sticky: !1, position: "top-right", theme: "bg-red" });
					$('button[type=submit]').prop('disabled', false);
					break;
				case 'success':
					//showSuccess(data.success);
					swal("Успешно", data.success, "success");
					//$.jGrowl(data.success, { sticky: !1, position: "top-right", theme: "bg-green" });
					if(data.url){
						//setTimeout("redirect("+data.url+")", 1500);
						setTimeout("redirect('/admin/auto')", 1500);
					}else{
						setTimeout("redirect('/admin/auto')", 1500);
					}
					//setTimeout("redirect('/')", 1500);
					break;
			}
   	},
   	  beforeSubmit: function(arr, $form, options) {
      $('button[type=submit]').prop('disabled', true);
   }
   });
   function toggleBuy() {
	var status = $('#act').is(':checked');
	if(status) {
		$('#price').prop('disabled', false);
	} else {
		$('#price').prop('disabled', true);
	}
}
</script>
<?php echo $footer ?>