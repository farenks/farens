<?php echo $admheader ?>
<div class="row">
	<div class="col-md-12">
		<div class="content-box">
			<h3 class="content-box-header bg-default">Список промо кодов</h3>
			<div class="content-box-wrapper">
				<table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered">
					<thead>
						<tr>
							<th>№</th>						
							<th>Код</th>
							<th>Скидка</th>
							<th>Использовано</th>
						</tr>
					</thead>
                  <tbody>
                     <?php foreach($promos as $item): ?>
                     <tr onClick="redirect('/admin/promo/edit/index/<?php echo $item['id'] ?>')">
                        <td><?php echo $item['id'] ?></td>
                        <td><?echo $item['cod']?></td>
                        <td><?php echo $item['skidka'] ?></td>
                        <td><?php echo $item['used'] ?>/<?php echo $item['uses'] ?></td>
                     </tr>
                     <?php endforeach; ?>
                     <?php if(empty($promos)): ?>
                     <tr>
                        <td colspan="4" class="text-center">На данный момент нет промо кодов.</td>
                     </tr>
                     <?php endif; ?> 
                  </tbody>
				</table>
			</div>
			<ul class="pagination pull-right">
				<?php echo $pagination ?>
			</ul>
		</div>
	</div>
</div>
<?php echo $footer ?>