<?php echo $admheader ?>
<div class="row">
	<div class="col-md-12">
		<div class="content-box">
			<h3 class="content-box-header bg-default">Редактирование промо-кода</h3>
      <div class="content-box-wrapper">
         <form class="form-group form-md-line-input" action="#" id="editForm" method="POST">
            <div class="form-group form-md-line-input">
               <input type="text" class="form-control" id="cod" name="cod" placeholder="Введите промо-код" value="<?php echo $promo['cod'] ?>">
            </div>
            <div class="form-group form-md-line-input">
               <select class="form-control" id="skidka" name="skidka" aria-required="true" aria-invalid="false" aria-describedby="delivery-error">
                  <option value="5" <?php if($promo['skidka'] == 5): ?> selected="selected"<?php endif; ?>>5%</option>
                  <option value="10" <?php if($promo['skidka'] == 10): ?> selected="selected"<?php endif; ?>>10%</option>
                  <option value="15" <?php if($promo['skidka'] == 15): ?> selected="selected"<?php endif; ?>>15%</option>
                  <option value="20" <?php if($promo['skidka'] == 20): ?> selected="selected"<?php endif; ?>>20%</option>
                  <option value="25" <?php if($promo['skidka'] == 25): ?> selected="selected"<?php endif; ?>>25%</option>
                  <option value="30" <?php if($promo['skidka'] == 30): ?> selected="selected"<?php endif; ?>>30%</option>
                  <option value="35" <?php if($promo['skidka'] == 35): ?> selected="selected"<?php endif; ?>>35%</option>
                  <option value="40" <?php if($promo['skidka'] == 40): ?> selected="selected"<?php endif; ?>>40%</option>
                  <option value="45" <?php if($promo['skidka'] == 45): ?> selected="selected"<?php endif; ?>>45%</option>
                  <option value="50" <?php if($promo['skidka'] == 50): ?> selected="selected"<?php endif; ?>>50%</option>
                  <option value="55" <?php if($promo['skidka'] == 55): ?> selected="selected"<?php endif; ?>>55%</option>
                  <option value="60" <?php if($promo['skidka'] == 60): ?> selected="selected"<?php endif; ?>>60%</option>
                  <option value="65" <?php if($promo['skidka'] == 65): ?> selected="selected"<?php endif; ?>>65%</option>
                  <option value="70" <?php if($promo['skidka'] == 70): ?> selected="selected"<?php endif; ?>>70%</option>
                  <option value="75" <?php if($promo['skidka'] == 75): ?> selected="selected"<?php endif; ?>>75%</option>
                  <option value="80" <?php if($promo['skidka'] == 80): ?> selected="selected"<?php endif; ?>>80%</option>
                  <option value="85" <?php if($promo['skidka'] == 85): ?> selected="selected"<?php endif; ?>>85%</option>
                  <option value="90" <?php if($promo['skidka'] == 90): ?> selected="selected"<?php endif; ?>>90%</option>
                  <option value="95" <?php if($promo['skidka'] == 95): ?> selected="selected"<?php endif; ?>>95%</option>
                  <option value="100" <?php if($promo['skidka'] == 100): ?> selected="selected"<?php endif; ?>>100%</option>
               </select>
            </div>
            <div class="form-group form-md-line-input">
               <input type="text" class="form-control" id="uses" name="uses" placeholder="Введите количество использований" value="<?php echo $promo['uses'] ?>">
            </div>
            <div class="m-btn-group m-btn-group--pill btn-group m-btn-group m-btn-group--pill btn-block" role="group" aria-label="Large button group">
               <button type="submit" class="button1 primary">Сохранить изменения</button>
               <a data-toggle="kt-tooltip" data-placement="right" title="" style="height: 3.1rem;" href="/admin/promo/edit/delete/<?php echo $promo['id'] ?>" class="button1 primary">Удалить промо-код</a>
            </div>
         </form>
      </div>			
		</div>
	</div>
</div>
<script>
   $('#editForm').ajaxForm({ 
   	url: '/admin/promo/edit/ajax/<?php echo $promo['id'] ?>',
   	dataType: 'text',
   	success: function(data) {
   		console.log(data);
   		data = $.parseJSON(data);
			switch(data.status) {
				case 'error':
					//showError(data.error);
					swal("Ошибка", data.error, "error");
					//$.jGrowl(data.error, { sticky: !1, position: "top-right", theme: "bg-red" });
					$('button[type=submit]').prop('disabled', false);
					break;
				case 'success':
					//showSuccess(data.success);
					swal("Успешно", data.success, "success");
					//$.jGrowl(data.success, { sticky: !1, position: "top-right", theme: "bg-green" });
					if(data.url){
						//setTimeout("redirect("+data.url+")", 1500);
						setTimeout("redirect('/admin/promo')", 1500);
					}else{
						setTimeout("redirect('/admin/promo')", 1500);
					}
					//setTimeout("redirect('/')", 1500);
					break;
			}
   	},
   	beforeSubmit: function(arr, $form, options) {
   		$('button[type=submit]').prop('disabled', true);
   	}
   });
</script>
<?php echo $footer ?>