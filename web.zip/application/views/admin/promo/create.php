<?php echo $admheader ?>
<div class="row">
	<div class="col-md-12">
		<div class="content-box">
			<h3 class="content-box-header bg-default">Создание промо-кода</h3>
			<div class="content-box-wrapper">
         <form class="form-group form-md-line-input" action="#" id="createForm" method="POST">
            <div class="form-group form-md-line-input">
               <input type="text" class="form-control" id="cod" name="cod" placeholder="Введите промо-код">
            </div>
            <div class="form-group form-md-line-input">
               <select class="form-control" id="skidka" name="skidka" aria-required="true" aria-invalid="false" aria-describedby="delivery-error">
                  <option value="5">5%</option>
                  <option value="10">10%</option>
                  <option value="15">15%</option>
                  <option value="20">20%</option>
                  <option value="25">25%</option>
                  <option value="30">30%</option>
                  <option value="35">35%</option>
                  <option value="40">40%</option>
                  <option value="45">45%</option>
                  <option value="50">50%</option>
                  <option value="55">55%</option>
                  <option value="60">60%</option>
                  <option value="65">65%</option>
                  <option value="70">70%</option>
                  <option value="75">75%</option>
                  <option value="80">80%</option>
                  <option value="85">85%</option>
                  <option value="90">90%</option>
                  <option value="95">95%</option>
                  <option value="100">100%</option>
               </select>
            </div>
            <div class="form-group form-md-line-input">
               <input type="text" class="form-control" id="uses" name="uses" placeholder="Введите количество использований">
            </div>
            <hr>
            <input type="submit" name="otp" class="button1 primary" value="Сохранить">
         </form>
			</div>
		</div>
</div>
</div>
<script>
   $('#createForm').ajaxForm({ 
    url: '/admin/promo/create/ajax',
    dataType: 'text',
    success: function(data) {
        console.log(data);
        data = $.parseJSON(data);
			switch(data.status) {
				case 'error':
					//showError(data.error);
					swal("Ошибка", data.error, "error");
					//$.jGrowl(data.error, { sticky: !1, position: "top-right", theme: "bg-red" });
					$('button[type=submit]').prop('disabled', false);
					break;
				case 'success':
					//showSuccess(data.success);
					swal("Успешно", data.success, "success");
					//$.jGrowl(data.success, { sticky: !1, position: "top-right", theme: "bg-green" });
					if(data.url){
						//setTimeout("redirect("+data.url+")", 1500);
						setTimeout("redirect('/admin/promo/')", 1500);
					}else{
						setTimeout("redirect('/admin/promo/')", 1500);
					}
					//setTimeout("redirect('/')", 1500);
					break;
			}
    },
    beforeSubmit: function(arr, $form, options) {
        $('button[type=submit]').prop('disabled', true);
    }
   });
</script>
<?php echo $footer ?>