<div class="col-md-12">
	<div class="remove-border dashboard-buttons clearfix">
		<a href="/admin/servers/control/index/<?php echo $server['server_id'] ?>" class="btn vertical-button remove-border btn-warning">
			<span class="glyph-icon icon-separator-vertical"><i class="glyph-icon icon-desktop"></i></span>
			<span class="button-content">Сервер</span>
		</a>
		<a href="/admin/servers/ftp/index/<?php echo $server['server_id'] ?>" class="btn vertical-button remove-border btn-purple">
			<span class="glyph-icon icon-separator-vertical"><i class="glyph-icon icon-file"></i></span>
			<span class="button-content">FTP</span>
		</a>
		<a href="/admin/servers/mysql/index/<?php echo $server['server_id'] ?>" class="btn vertical-button remove-border btn-yellow">
			<span class="glyph-icon icon-separator-vertical"><i class="glyph-icon icon-database"></i></span>
			<span class="button-content">MySQL</span>
		</a>
		<a href="/admin/servers/serverStatistics/index/<?php echo $server['server_id'] ?>" class="btn vertical-button remove-border btn-azure">
			<span class="glyph-icon icon-separator-vertical"><i class="glyph-icon icon-bar-chart"></i></span>
			<span class="button-content">Статистика</span>
		</a>
		<a href="/admin/servers/serverLogs/index/<?php echo $server['server_id'] ?>" class="btn vertical-button remove-border btn-success">
			<span class="glyph-icon icon-separator-vertical"><i class="glyph-icon icon-file-code-o"></i></span>
			<span class="button-content">Логи</span>
		</a>
		<a href="/admin/servers/config/index/<?php echo $server['server_id'] ?>" class="btn vertical-button remove-border btn-blue-alt">
			<span class="glyph-icon icon-separator-vertical"><i class="glyph-icon icon-file-code-o"></i></span>
			<span class="button-content">Конфигурация</span>
		</a>
	</div>
</div>