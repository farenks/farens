<?php echo $admheader ?>
<div class="row">
	<?php include 'menu.php';?>
	<div class="col-md-12">
		<div class="content-box">
			<h3 class="content-box-header bg-default">MySQL доступ</h3>
			<div class="content-box-wrapper">
				<div class="row">
					<div class="col-md-5">
						<table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered">
							<tbody>
								<tr>
									<th>Хост:</th>
									<td><?php echo $server['location_ip'] ?></td>
								</tr>
								<tr>
									<th>Порт:</th>
									<td>3306</td>
								</tr>
								<tr>
									<th>Логин:</th>
									<td>gs<?php echo $server['server_id'] ?></td>
								</tr>
								<tr>
									<th>Пароль:</th>
									<td><?php echo $server['database_password'] ?></td>
								</tr>
							</tbody>
						</table>
					</div>
					<div class="col-md-7">
						<form class="form-horizontal" action="#" id="editFormMysql" method="POST">
							<div class="form-group">
								<div class="col-sm-5">
									<div class="checkbox">
										<label><input type="checkbox" id="editpasswordmysql" name="editpasswordmysql" onChange="togglePasswordMysql()"> Изменить пароль</label>
									</div>
								</div>
								<label for="password" class="col-sm-3 control-label">Пароль:</label>
								<div class="col-sm-4">
									<input type="password" class="form-control" id="passwordmysql" name="passwordmysql" placeholder="Введите пароль" disabled>
								</div>
							</div>
							<div class="form-group">
								<div class="col-sm-5">
									<button type="submit" class="btn btn-primary">Сохранить</button>
									<button type="button" class="btn btn-success" onClick="generatePassMysql()">Сгенерировать пароль</button>
									<a href="/phpmyadmin" target="_blank" class="btn btn-warning">Войти</a>
								</div>
								<label for="password2" class="col-sm-3 control-label">Повтор пароля:</label>
								<div class="col-sm-4">
									<input type="password" class="form-control" id="password2mysql" name="password2mysql" placeholder="Повторите пароль" disabled>
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<script>
	$('#editFormMysql').ajaxForm({ 
		url: '/admin/servers/control/ajax/<?php echo $server['server_id'] ?>',
		dataType: 'text',
		success: function(data) {
			console.log(data);
			data = $.parseJSON(data);
			switch(data.status) {
				case 'error':
					//showError(data.error);
					$.jGrowl(data.error, { sticky: !1, position: "top-right", theme: "bg-red" });
					$('button[type=submit]').prop('disabled', false);
					break;
				case 'success':
					//showSuccess(data.success);
					$.jGrowl(data.success, { sticky: !1, position: "top-right", theme: "bg-green" });
					setTimeout("reload()", 1500);
					break;
			}
		},
		beforeSubmit: function(arr, $form, options) {
			$('button[type=submit]').prop('disabled', true);
		}
	});
	function togglePasswordMysql() {
		var status = $('#editpasswordmysql').is(':checked');
		if(status) {
			$('#passwordmysql').prop('disabled', false);
			$('#password2mysql').prop('disabled', false);
		} else {
			$('#passwordmysql').prop('disabled', true);
			$('#password2mysql').prop('disabled', true);
		}
	}
	function makeRand(max){
		return Math.floor(Math.random() * max);
	}
	function generatePassMysql(){
		var length = 12;
		var result = '';
		var symbols = new Array(
					'q','w','e','r','t','y','u','i','o','p',
					'a','s','d','f','g','h','j','k','l',
					'z','x','c','v','b','n','m',
					'Q','W','E','R','T','Y','U','I','O','P',
					'A','S','D','F','G','H','J','K','L',
					'Z','X','C','V','B','N','M',
					1,2,3,4,5,6,7,8,9,0
		);
		for (i = 0; i < length; i++){
			result += symbols[makeRand(symbols.length)];
		}
		document.getElementById('passwordmysql').setAttribute('type', 'text');
		document.getElementById('passwordmysql').value = result;
		document.getElementById('password2mysql').setAttribute('type', 'text');
		document.getElementById('password2mysql').value = result;
	}
</script>
<?php echo $footer ?>