<?php echo $admheader ?>
<div class="row">
	<?php include 'menu.php';?>
	<div class="col-md-6">
		<div class="content-box">
			<h3 class="content-box-header bg-default">Управление сервером</h3>
			<div class="content-box-wrapper">
				<table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered">
					<tbody>
						<tr>
							<th>Статус:</th>
							<td>
								<?php if($server['server_status'] == 0): ?>
								<span class="bs-label label-warning">Заблокирован</span>
								<?php elseif($server['server_status'] == 1): ?>
								<span class="bs-label label-danger">Выключен</span>
								<?php elseif($server['server_status'] == 2): ?>
								<span class="bs-label label-success">Включен</span>
								<?php elseif($server['server_status'] == 3): ?>
								<span class="bs-label label-warning">Установка</span>
								<?php elseif($server['server_status'] == 4): ?>
								<span class="bs-label label-black">Заблокирован администратором</span>
								<?php endif; ?>
							</td>
						</tr>
						<tr>
							<th>Игра:</th>
							<td><?php echo $server['game_name'] ?></td>
						</tr>
						<tr>
							<th>Локация:</th>
							<td><?php echo $server['location_name'] ?></td>
						</tr>
						<tr>
							<th>Адрес:</th>
							<td><?php echo $server['location_ip'] ?>:<?php echo $server['server_port'] ?></td>
						</tr>
						<tr>
							<th>Слоты:</th>
							<td><?php echo $server['server_slots'] ?></td>
						</tr>
						<tr>
							<th>Владелец:</th>
							<td><a href="/admin/users/edit/index/<?php echo $server['user_id'] ?>"><?php echo $server['user_firstname'] ?> <?php echo $server['user_lastname'] ?></a></td>
						</tr>
						<tr>
							<th>Дата окончания оплаты:</th>
							<td><?php echo date("d.m.Y", strtotime($server['server_date_end'])) ?></td>
						</tr>
					</tbody>
				</table>
			</div>
		</div>
		<?php if($server['server_status'] == 0): ?>
		<a href="/servers/pay/index/<?php echo $server['server_id'] ?>" class="btn btn-primary">Продлить</a>
		<button type="button" class="btn btn-success" onClick="sendAction(<?php echo $server['server_id'] ?>,'unblock')">Разблокировать</button>
		<?php elseif($server['server_status'] == 4): ?>
		<button type="button" class="btn btn-success" onClick="sendAction(<?php echo $server['server_id'] ?>,'admin_unblock')">Разблокировать администратором</button>
		<?php elseif($server['server_status'] == 1): ?>
		<button type="button" class="btn btn-success" onClick="sendAction(<?php echo $server['server_id'] ?>,'start')">Включить</button>
		<button type="button" class="btn btn-warning" onClick="sendAction(<?php echo $server['server_id'] ?>,'reinstall')">Переустановить</button>
		<a href="/admin/servers/pay/index/<?php echo $server['server_id'] ?>" class="btn btn-primary">Продлить</a><br><br>
		<button type="button" class="btn btn-danger" onClick="sendAction(<?php echo $server['server_id'] ?>,'delete')">Удалить</button>
		<button type="button" class="btn btn-danger" onClick="sendAction(<?php echo $server['server_id'] ?>,'block')">Заблокировать</button>
		<button type="button" class="btn btn-black" onClick="sendAction(<?php echo $server['server_id'] ?>,'admin_block')">Заблокировать администратором</button>
		<?php elseif($server['server_status'] == 2): ?>
		<button type="button" class="btn btn-danger" onClick="sendAction(<?php echo $server['server_id'] ?>,'stop')">Выключить</button>
		<button type="button" class="btn btn-info" onClick="sendAction(<?php echo $server['server_id'] ?>,'restart')">Перезапустить</button>
		<a href="/admin/servers/pay/index/<?php echo $server['server_id'] ?>" class="btn btn-primary">Продлить</a>
		<?php endif; ?>
	</div>
	<div class="col-md-6">
		<div class="content-box">
			<h3 class="content-box-header bg-default">База знаний</h3>
			<div class="content-box-wrapper">
				<ul class="nav-responsive nav nav-pills">
					<li class="active"><a href="#general-questions" data-toggle="tab">Общие вопросы</a></li>
					<li><a href="#gta-samp" data-toggle="tab">GTA SAMP</a></li>
					<li><a href="#gta-mta" data-toggle="tab">GTA MTA</a></li>
					<li><a href="#cs-16" data-toggle="tab">Counter Strike 1.6</a></li>
					<li><a href="#cs-s" data-toggle="tab">Counter Strike Source</a></li>
				</ul>
				<div class="tab-content">
					<div class="tab-pane active" id="general-questions">
						<div class="divider"></div>
						<li><b>Основная информация о хостинге.</b></li>
						<b>1. Мы не отвечаем за работоспособность или стабильность вашего сервера с установленными вами не стандартными плагинами, картами и другими файлами.</b><br>
						<b>2. Мы не несем ответственности за работоспособность сервера при вашей самостоятельной его настройке, наша задача предоставить вам выделенный полностью рабочий сервер.</b><br>
						<b>3. Мы не обязаны, исправлять какие либо ваши ошибки после которых, сервер не запускается или работает нестабильно. Возможно мы сможем помочь вам в каких-либо вопросах связанных с настройкой, но задавать их нужно в техническую поддержку.</b>
						<div class="divider"></div>
						<li><b>В обязанности службы поддержки не входит:</b></li>
						<b>1. Установка и настройка плагинов, модов, звуков, и других файлов даже в том случае, если клиент сам не в состоянии их настроить.</b><br>
						<b>2. Делать за клиента операции, которые он может сделать сам через FTP, MySQL или панель управления.</b><br>
						<b>3. Проводить обучение по настройке плагинов, по работе с серверами и другими услугами.</b><br>
						<b>4. Отвечать на вопросы которые не имеют отношения к сервисам хостинга.</b>
						<div class="divider"></div>
						<li><b>Через сколько удаляется сервер если его не оплачивать?</b></li>
						<b>Сервер удаляется через 72 часа с момента его отключения за неуплату.</b>
						<div class="divider"></div>
					</div>
					<div class="tab-pane" id="gta-samp">
						<div class="divider"></div>
						<li><b>Установка плагинов и модов на сервер.</b></li>
						<b>1. Для установки плагинов на сервер вам нужно:</b><br>
						<b>2. Загрузить плагины на сервер в каталог plugins игрового сервера через FTP доступ.</b><br>
						<b>3. Прописать необходимые плагины в файле server.cfg. (Пример: plugins sscanf.so mysql.so streamer.so).</b><br>
						<b>4. На нашем хостинге установлена ОС Linux, поэтому плагины необходимо устанавливать только с расширением .so</b>
						<div class="divider"></div>
						<li><b>Сервер Unknown или Run time error 19.</b></li>
						<b>Данная ошибка возникает из-за отсутствия плагина, или же из-за отсутсвия прописанного плагина в server.cfg так же возможно не соответствует релиз с модом.</b>
						<div class="divider"></div>
						<li><b>Не запускается сервер.</b></li>
						<b>Техническая поддержка не несет ответственности за установленные сторонние моды, если у вас возникла проблема с запуском сервера в первую очередь вам нужно зайти в логи сервера и посмотреть с чем связана ошибка и попытаться ее решить, и только после этого если у вас ничего не получиться написать запрос в техническую поддержку.</b>
						<div class="divider"></div>
					</div>
					<div class="tab-pane" id="gta-mta">
						<div class="divider"></div>
						<li><b>Как прописать себе администратора на сервере?</b></li>
						<b>1. Выключить сервер.</b><br>
						<b>2. Зайти через FTP доступ в корень сервера.</b><br>
						<b>3. Перейти в папку mods/deathmatch</b><br>
						<b>4. Открыть файл acl.xml.</b><br>
						<b>5. Ищем строку group name="Admin".</b><br>
						<b>6. Выше строки object name="resource.admin" вставляем строку object name="user.Никнейм"</b><br>
						<b>7. Сохраняем файл и включаем сервер.</b><br>
						<div class="divider"></div>
					</div>
					<div class="tab-pane" id="cs-16">
						<div class="divider"></div>
						<li><b>Как прописать себе администратора на сервере?</b></li>
						<b>1. Установить дополнение AmxModX.</b><br>
						<b>2. Зайти через FTP доступ в корень сервера.</b><br>
						<b>3. Перейти в папку cstrike/addons/amxmodx/configs</b><br>
						<b>4. Открыть файл users.ini.</b><br>
						<b>5. Выбрать способ выдачи администратора:</b><br>
						<b>Администратор по ІР: "IP" "" "abcdefghijklmnopqrstu" "de"</b><br>
						<b>Администратор по Никнейму: "Никнейм" "Пароль" "abcdefghijklmnopqrstu" "a"</b><br>
						<b>Администратор по SteamID: "SteamID" "" "abcdefghijklmnopqrstu" "ce"</b><br>
						<b>6. Вставить строку в конец файла users.ini и отредактировать ее под себя.</b><br>
						<b>7. Сохраняем файл users.ini и перезапускаем сервер.</b><br>
						<b>Если вы выдали адмиинстратора по ІР или SteamID то просто зайдите на сервер и введите в консоле: amxmodmenu.</b><br>
						<b>Если вы выдали адмиинстратора по никнейму то перед тем как войдти на сервер введите в консоле "setinfo _pw Пароль" после чего зайдите на сервер и введите в консоле amxmodmenu.</b>
						<div class="divider"></div>
					</div>
					<div class="tab-pane" id="cs-s">
						<div class="divider"></div>
						<li><b>Как прописать себе администратора на сервере?</b></li>
						<b>1. Установить дополнение Sourcemod.</b><br>
						<b>2. Зайти через FTP доступ в корень сервера.</b><br>
						<b>3. Перейти в папку cstrike/addons/sourcemod/configs</b><br>
						<b>4. Открыть файл admins_simple.ini.</b><br>
						<b>5. Выбрать способ выдачи администратора:</b><br>
						<b>Администратор по ІР: "!IP" "99:z"</b><br>
						<b>Администратор по Никнейму: "Никнейм" "abcdefghijklmzopqrst" "Пароль"</b><br>
						<b>Администратор по SteamID: "SteamID" "abcdefghijklmzopqrst"</b><br>
						<b>6. Вставить строку в конец файла admins_simple.ini и отредактировать ее под себя.</b><br>
						<b>7. Сохраняем файл admins_simple.ini.</b><br>
						<b>8. Открыть файл core.cfg.</b><br>
						<b>9. Заменить строку "_password" на "_pw".</b><br>
						<b>10. Перезапускаем сервер.</b><br>
						<b>Если вы выдали адмиинстратора по ІР или SteamID то просто зайдите на сервер и введите в консоле: sm_admin.</b><br>
						<b>Если вы выдали адмиинстратора по никнейму то перед тем как войдти на сервер введите в консоле "setinfo _pw Пароль" после чего зайдите на сервер и введите в консоле sm_admin.</b>
						<div class="divider"></div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<script>
	function sendAction(serverid, action) {
		switch(action) {
			case "delete":
			{
				if(!confirm("Вы уверенны в том, что хотите удалить сервер? Все данные будут удалены.")) return;
				break;
			}
			case "reinstall":
			{
				if(!confirm("Вы уверенны в том, что хотите переустановить сервер? Все данные будут удалены.")) return;
				break;
			}
		}
		$.ajax({ 
			url: '/admin/servers/control/action/'+serverid+'/'+action,
			dataType: 'text',
			success: function(data) {
				console.log(data);
				data = $.parseJSON(data);
				switch(data.status) {
					case 'error':
						//showError(data.error);
						$.jGrowl(data.error, { sticky: !1, position: "top-right", theme: "bg-red" });
						$('#controlBtns button').prop('disabled', false);
						break;
					case 'success':
						//showSuccess(data.success);
						$.jGrowl(data.success, { sticky: !1, position: "top-right", theme: "bg-green" });
						setTimeout("reload()", 1500);
						break;
				}
			},
			beforeSend: function(arr, options) {
				//if(action == "reinstall") showWarning("Сервер будет переустановлен в течении 10 минут!");
				if(action == "reinstall") $.jGrowl("Сервер будет переустановлен в течении 10 минут!", { sticky: !1, position: "top-right", theme: "bg-yellow" });
				$('#controlBtns button').prop('disabled', true);
			}
		});
	}
</script>
<?php echo $footer ?>