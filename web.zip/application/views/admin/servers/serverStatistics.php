<?php echo $admheader ?>
<?php if($server['server_status'] == 2): ?>
<div class="row">
	<?php include 'menu.php';?>
	<div class="col-md-12">
		<div class="content-box">
			<h3 class="content-box-header bg-default">Статистика сервера</h3>
			<div class="content-box-wrapper">
				<div class="row">
					<div class="col-md-4">
						<table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered">
							<tbody>
								<?php if($query): ?> 
								<tr>
									<th>Название:</th>
									<td><?php echo $query['hostname'] ?></td>
								</tr>
								<tr>
									<th>Игроки:</th>
									<td><?php echo $query['players'] ?> из <?php echo $query['maxplayers'] ?></td>
								</tr>
								<tr>
									<th>Игровой режим:</th>
									<td><?php echo $query['gamemode'] ?></td>
								</tr>
								<tr>
									<th>Карта:</th>
									<td><?php if($server['game_code'] == 'samp') { echo 'San Andreas';} elseif($server['game_code'] == 'mtasa') { echo 'San Andreas';} else {echo $query['mapname']; }?></td>
								</tr>
								<tr>
									<th>Нагрузка RAM</th>
									<td>Частота обновления 5 минут</td>
								</tr>
								<tr>
									<th>Нагрузка CPU</th>
									<td>Частота обновления 1 час</td>
								</tr>
								<?php endif; ?>
							</tbody>
						</table>
					</div>
					<div class="col-md-2">
						<a href="#" class="tile-box tile-box-alt btn-black">
							<div class="tile-header">Нагрузка CPU</div>
							<div class="tile-content-wrapper">
								<div class="chart-alt-10" data-percent="<?php echo $server['server_cpu_load'] ?>"><span><?php echo $server['server_cpu_load'] ?></span>%</div>
							</div>
						</a>
						<br>
						<a href="#" class="tile-box tile-box-alt btn-warning">
							<div class="tile-header">Нагрузка RAM</div>
							<div class="tile-content-wrapper">
								<div class="chart-alt-10" data-percent="<?php echo $server['server_ram_load'] ?>"><span><?php echo $server['server_ram_load'] ?></span>%</div>
							</div>
						</a>
					</div>
					<div class="col-md-6">
						<div id="statsGraph" style="height: 320px; width: 750px;"></div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php elseif($server['server_status'] == 1): ?>
<div class="row">
	<?php include 'menu.php';?>
	<div class="col-md-12">
		<div class="content-box">
			<h3 class="content-box-header bg-default">Статистика сервера</h3>
			<div class="content-box-wrapper">
				Статистика сервера показывается только тогда, когда сервер включен!
			</div>
		</div>
	</div>
</div>
<?php elseif($server['server_status'] == 0): ?>
<div class="row">
	<?php include 'menu.php';?>
	<div class="col-md-12">
		<div class="content-box">
			<h3 class="content-box-header bg-default">Статистика сервера</h3>
			<div class="content-box-wrapper">
				Статистика сервера показывается только тогда, когда сервер будет разблокирован и включен!
			</div>
		</div>
	</div>
</div>
<?php elseif($server['server_status'] == 4): ?>
<div class="row">
	<?php include 'menu.php';?>
	<div class="col-md-12">
		<div class="content-box">
			<h3 class="content-box-header bg-default">Статистика сервера</h3>
			<div class="content-box-wrapper">
				Статистика сервера показывается только тогда, когда сервер будет разблокирован администратором и включен!
			</div>
		</div>
	</div>
</div>
<?php endif; ?>
<script>
	var serverStats = [
		<?php foreach($stats as $item): ?> 
		[<?php echo strtotime($item['server_stats_date'])*1000 ?>, <?php echo $item['server_stats_players'] ?>],
		<?php endforeach; ?> 
	];
	$.plot($("#statsGraph"), [serverStats], {
		xaxis: {
			mode: "time",
			timeformat: "%H:%M"
		},
		yaxis: {
			min: 0,
			max: <?php echo $server['server_slots'] ?>
		},
		series: {
			lines: {
				show: true,
				fill: true
			},
			points: {
				show: true
			}
		},
		grid: {
			borderWidth: 0
		},
		colors: [ "#428BCA" ]
	});
</script>
<?php echo $footer ?>