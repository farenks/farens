<?php echo $admheader ?>
<div class="row">
	<?php include 'menu.php';?>
		<div class="col-md-12">
			<div class="content-box">
			<h3 class="content-box-header bg-default">Логи сервера<span style="float:right;"><div class="checkbox" data-toggle="tooltip" data-placement="top" title="Автообновление консоли каждые 15 секунд."><input type="checkbox" checked id="autoscroll" onChange="checkauto()">Автообновление</div></span></h3>
				<div class="content-box-wrapper">
					<div class="portlet light ">
					<div class="portlet-body" style="padding-top: 0px;">
					<center><h5 id="text"></h5></center>
						<div class="table-scrollable table-scrollable-borderless" style="margin-top: 0px !important;">
							<textarea  rows="20" id="textAreaObject" class="form-control" >Загрузка...</textarea>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<script>
	function updatelog() {
		var serverid = '<?=$server['server_id']?>';
		var locationid = '<?=$server['location_id']?>';
		var autoscroll = document.getElementById("autoscroll");
		if (autoscroll.checked==false)
		{
			setTimeout(updatelog,1000);
			return;
		}
		$.get("/console.php?action=getconsole",{serverid: serverid , locationid: locationid} )			
		.done(function(data) {
			displayconsole(serverid,data);
			setTimeout(updatelog,1000);
			}); 
		}
		function displayconsole(serverid,sText) {
			var divInfo = document.getElementById("textAreaObject");
			console.log(sText);
			divInfo.innerHTML =  sText;
			divInfo.scrollTop = divInfo.scrollHeight;
			return;
		}
		$(document).ready(function() {
			updatelog();
		});
</script>
<?php echo $footer ?>