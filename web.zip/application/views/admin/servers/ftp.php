<?php echo $admheader ?>
<div class="row">
	<?php include 'menu.php';?>
	<div class="col-md-12">
		<div class="content-box">
			<h3 class="content-box-header bg-default">FTP доступ</h3>
			<div class="content-box-wrapper">
				<div class="row">
					<div class="col-md-5">
						<table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered">
							<tbody>
								<tr>
									<th>Хост:</th>
									<td><?php echo $server['location_ip'] ?></td>
								</tr>
								<tr>
									<th>Порт:</th>
									<td>21</td>
								</tr>
								<tr>
									<th>Логин:</th>
									<td>gs<?php echo $server['server_id'] ?></td>
								</tr>
								<tr>
									<th>Пароль:</th>
									<td><?php echo $server['server_password'] ?></td>
								</tr>
							</tbody>
						</table>
					</div>
					<div class="col-md-7">
						<form class="form-horizontal" action="#" id="editForm" method="POST">
							<div class="form-group">
								<div class="col-sm-5">
									<div class="checkbox">
										<label><input type="checkbox" id="editpassword" name="editpassword" onChange="togglePassword()"> Изменить пароль</label>
									</div>
								</div>
								<label for="password" class="col-sm-2 control-label">Пароль:</label>
								<div class="col-sm-4">
									<input type="password" class="form-control" id="password" name="password" placeholder="Введите пароль" disabled>
								</div>
							</div>
							<div class="form-group">
								<div class="col-sm-5">
									<button type="submit" class="btn btn-primary">Сохранить</button>
									<button type="button" class="btn btn-success" onClick="generatePass()">Сгенерировать пароль</button>
								</div>
								<label for="password2" class="col-sm-2 control-label">Повтор пароля:</label>
								<div class="col-sm-4">
									<input type="password" class="form-control" id="password2" name="password2" placeholder="Повторите пароль" disabled>
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<script>
	$('#editForm').ajaxForm({ 
		url: '/admin/servers/control/ajax/<?php echo $server['server_id'] ?>',
		dataType: 'text',
		success: function(data) {
			console.log(data);
			data = $.parseJSON(data);
			switch(data.status) {
				case 'error':
					//showError(data.error);
					$.jGrowl(data.error, { sticky: !1, position: "top-right", theme: "bg-red" });
					$('button[type=submit]').prop('disabled', false);
					break;
				case 'success':
					//showSuccess(data.success);
					$.jGrowl(data.success, { sticky: !1, position: "top-right", theme: "bg-green" });
					setTimeout("reload()", 1500);
					break;
			}
		},
		beforeSubmit: function(arr, $form, options) {
			$('button[type=submit]').prop('disabled', true);
		}
	});
	function togglePassword() {
		var status = $('#editpassword').is(':checked');
		if(status) {
			$('#password').prop('disabled', false);
			$('#password2').prop('disabled', false);
		} else {
			$('#password').prop('disabled', true);
			$('#password2').prop('disabled', true);
		}
	}
	function makeRand(max){
		return Math.floor(Math.random() * max);
	}
	function generatePass(){
		var length = 12;
		var result = '';
		var symbols = new Array(
					'q','w','e','r','t','y','u','i','o','p',
					'a','s','d','f','g','h','j','k','l',
					'z','x','c','v','b','n','m',
					'Q','W','E','R','T','Y','U','I','O','P',
					'A','S','D','F','G','H','J','K','L',
					'Z','X','C','V','B','N','M',
					1,2,3,4,5,6,7,8,9,0
		);
		for (i = 0; i < length; i++){
			result += symbols[makeRand(symbols.length)];
		}
		document.getElementById('password').setAttribute('type', 'text');
		document.getElementById('password').value = result;
		document.getElementById('password2').setAttribute('type', 'text');
		document.getElementById('password2').value = result;
	}
</script>
<?php echo $footer ?>