<?php echo $admheader ?>
<div class="row">
	<div class="col-md-12">
		<div class="content-box">
			<h3 class="content-box-header bg-default">Настройки хостинга</h3>
			<div class="content-box-wrapper">
				<form class="form-horizontal" id="settings" method="post" action="" novalidate="novalidate">
                  <div class="form-group">
                     <label class="col-sm-4 control-label control-label"> URL сайта</label>
					 <div class="col-sm-4">
                     <input type="text" class="form-control" id="url" name="url" placeholder="Введите URL сайта" value="<?php echo $settings['url'] ?>">
					 </div>
                  </div>
                  <div class="form-group">
                     <label class="col-sm-4 control-label"> Название сайта</label>
					 <div class="col-sm-4">
                     <input type="text" class="form-control" id="title" name="title" placeholder="Введите название сайта" value="<?php echo $settings['title'] ?>">
					 </div>
                  </div>
                  <div class="form-group">
                     <label class="col-sm-4 control-label"> Описание сайта</label>
					 <div class="col-sm-4">
                     <input type="text" class="form-control" id="description" name="description" placeholder="Введите описание сайта" value="<?php echo $settings['description'] ?>">
					 </div>
                  </div>
                  <div class="form-group">
                     <label class="col-sm-4 control-label"> Ключевые слова</label>
					 <div class="col-sm-4">
                     <input type="text" class="form-control" id="keywords" name="keywords" placeholder="Введите ключевые слова" value="<?php echo $settings['keywords'] ?>">
					 </div>
                  </div>
                  <div class="form-group">
                     <label class="col-sm-4 control-label"> Имя отправителя</label>
					 <div class="col-sm-4">
                     <input type="text" class="form-control" id="mail_sender" name="mail_sender" placeholder="Введите имя отправителя" value="<?php echo $settings['mail_sender'] ?>">
					 </div>
                  </div>
                  <div class="form-group">
                     <label class="col-sm-4 control-label"> E-mail Службы поддержки</label>
					 <div class="col-sm-4">
                     <input type="text" class="form-control" id="mail_from" name="mail_from" placeholder="Введите E-mail Службы поддержки" value="<?php echo $settings['mail_from'] ?>">
					 </div>
                  </div>
                  <div class="form-group">
                     <label class="col-sm-4 control-label"> ID Вашей группы ВКонтакте</label>
					 <div class="col-sm-4">
                     <input type="text" class="form-control" id="public" name="public" placeholder="Введите ID Вашей группы ВКонтакте" value="<?php echo $settings['public'] ?>">
					 </div>
                  </div>
				   <div class="form-group">
                     <label class="col-sm-4 control-label">Стоимость смены порта</label>
					 <div class="col-sm-4">
                     <input type="text" class="form-control" id="portPrice" name="portPrice" placeholder="Введите сумму " value="<?php echo $settings['portPrice'] ?>">
					 </div>
                  </div>
				  <center><button type="submit" class="button1 success">Применить настройки</button></center>
				</form>
			</div>
		</div>
<script>
	$('#settings').ajaxForm({ 
		url: '/admin/settings/ajax',
		dataType: 'text',
		success: function(data) {
			console.log(data);
			data = $.parseJSON(data);
			switch(data.status) {
				case 'error':
					//showError(data.error);
					$.jGrowl(data.error, { sticky: !1, position: "top-right", theme: "bg-red" });
					$('button[type=submit]').prop('disabled', false);
					break;
				case 'success':
					//showSuccess(data.success);
					$.jGrowl(data.success, { sticky: !1, position: "top-right", theme: "bg-green" });
					setTimeout("redirect('/admin/settings/index')", 4000);
					break;
			}
		},
		beforeSubmit: function(arr, $form, options) {
			$('button[type=submit]').prop('disabled', true);
		}
	});
</script>
<?php echo $footer ?>