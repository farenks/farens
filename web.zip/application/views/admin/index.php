<?php echo $admheader ?>
<div class="row">
	<div class="col-md-3">
		<div class="content-box">
			<h3 class="content-box-header bg-primary"><i class="glyph-icon icon-user"></i> Администраторы</h3>
			<div class="content-box-wrapper">
				<?php foreach($users as $item): ?>
				<?if($item['user_access_level'] == 1)
				continue;?>
				<p><b>Данные: <a href="/admin/users/edit/index/<?php echo $item['user_id'] ?>" class="kt-widget__title">
                           <?php echo $item['user_firstname'] ?> <?php echo $item['user_lastname'] ?>
                           </a></b></p>
				<div class="divider"></div>
				<p><b>Должность: <?php if($item['user_access_level'] == 2): ?>
                           Тех. поддержка
                           <?php elseif($item['user_access_level'] == 3): ?>
                           Администратор</b></p>
				<div class="divider"></div>
                           <?php endif; ?> 
				<?php endforeach; ?>
			</div>
		</div>
	</div>
	<div class="col-md-3">
		<div class="content-box">
			<h3 class="content-box-header bg-purple"><i class="glyph-icon icon-dashboard"></i> Статистика Хостинга</h3>
			<div class="content-box-wrapper">
				<p><b>Пользователей: <a href="/admin/users/index"><span><?$userov = 0;
                           foreach($users as $item): ?>
                        <? $userov++; ?>
                        <?endforeach;echo $userov; ?></span></b></p></a>
				<div class="divider"></div>
				<p><b>Создано серверов: <a href="/admin/servers/index"><span><?$tserverov1 = 0;
                           foreach($tservers as $item): ?>
                        <? $tserverov1++; ?>
                        <?endforeach;echo $tserverov1; ?></span></b></p></a>
				<div class="divider"></div>
				<p><b>Создано тикетов: <a href="/admin/tickets/index"><span><?$ticketov = 0;
                           foreach($tickets as $item): ?>
                        <? $ticketov++; ?>
                        <?endforeach;echo $ticketov; ?></span></b></p></a>
						<div class="divider"></div>
						<p><b>Платежей: <a href="/admin/invoices/index"><span><?$invo = 0;
                           foreach($invoices as $item): ?>
                        <? if (!($item['invoice_status'] == 1)) { // пропуск нечетных чисел
                           continue;
                           }?>
                        <? $invo=$invo+$item['invoice_ammount']; ?>
                        <?endforeach; echo $invo; ?> </span> - Заработано</b></p></a>
						<b><td colspan="6" style="text-align: center;">Последний счёт: <a href="/admin/invoices/index"><?echo $item['invoice_ammount'];?> ₽</td></b></a>
						<div class="divider"></div>
			</div>
		</div>
	</div>
	<div class="col-md-3">
		<div class="content-box">
			<h3 class="content-box-header bg-red"><i class="glyph-icon icon-hdd-o"></i> Управление</h3>
			<div class="content-box-wrapper">
				<p><b>Игры - <a href="/admin/games/create">Создать игру</b></p></a>
				<div class="divider"></div>
				<p><b>Локации - <a href="/admin/locations/create">Создать локацию</b></p></a>
				<div class="divider"></div>
			</div>
		</div>
	</div>
</div>
<?php echo $footer ?>