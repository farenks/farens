<?php echo $admheader ?>
<div class="row">
	<div class="col-md-12">
		<div class="content-box">
			<h3 class="content-box-header bg-default">Настройки хостинга</h3>
			<div class="content-box-wrapper">
				<form class="form-horizontal" id="settings" method="post" action="" novalidate="novalidate">
                  <div class="form-group">
                     <label class="col-sm-4 control-label">Касса PayOK</label>
					 <div class="col-sm-4">
                     <input type="text" class="form-control" id="payok" name="payok" placeholder="Введите 1 - включено 0 - выключено" value="<?php echo $settings['payok'] ?>">
					 </div>
                  </div>
                  <div class="form-group">
                     <label class="col-sm-4 control-label">ID Кассы</label>
					 <div class="col-sm-4">
                     <input type="text" class="form-control" id="payok_id" name="payok_id" placeholder="Введите ID кассы" value="<?php echo $settings['payok_id'] ?>">
					 </div>
                  </div>
                  <div class="form-group">
                     <label class="col-sm-4 control-label">Ключ кассы</label>
					 <div class="col-sm-4">
                     <input type="text" class="form-control" id="payok_key" name="payok_key" placeholder="Введите секретный ключ кассы" value="<?php echo $settings['payok_key'] ?>">
					 </div>
                  </div>
				  <center><button type="submit" class="button1 success">Сохранить</button></center>
				</form>
			</div>
		</div>
<script>
	$('#settings').ajaxForm({ 
		url: '/admin/settings/ajax',
		dataType: 'text',
		success: function(data) {
			console.log(data);
			data = $.parseJSON(data);
			switch(data.status) {
				case 'error':
					//showError(data.error);
					$.jGrowl(data.error, { sticky: !1, position: "top-right", theme: "bg-red" });
					$('button[type=submit]').prop('disabled', false);
					break;
				case 'success':
					//showSuccess(data.success);
					$.jGrowl(data.success, { sticky: !1, position: "top-right", theme: "bg-green" });
					setTimeout("redirect('/admin/kassa/index')", 4000);
					break;
			}
		},
		beforeSubmit: function(arr, $form, options) {
			$('button[type=submit]').prop('disabled', true);
		}
	});
</script>
<?php echo $footer ?>