<?php echo $admheader ?>
<div class="row">
	<div class="col-md-12">
		<div class="content-box">
			<h3 class="content-box-header bg-default">Все игры</h3>
			<div class="content-box-wrapper">
				<table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered">
					<thead>
						<tr>
							<th>ID</th>
							<th>Статус</th>
							<th>Название</th>
							<th>Код</th>
							<th>Слоты</th>
							<th>Порты</th>
							<th>Стоимость</th>
							<th>Действия</th>
						</tr>
					</thead>
					<tbody>
						<?php foreach($games as $item): ?>
						<tr>
							<td>#<?php echo $item['game_id'] ?></td>
							<td>
								<?php if($item['game_status'] == 0): ?>
								<span class="bs-label label-danger">Выключена</span>
								<?php elseif($item['game_status'] == 1): ?>
								<span class="bs-label label-success">Включена</span>
								<?php endif; ?>
							</td>
							<td><?php echo $item['game_name'] ?></td>
							<td><?php echo $item['game_code'] ?></td>
							<td><?php echo $item['game_min_slots'] ?> - <?php echo $item['game_max_slots'] ?></td>
							<td><?php echo $item['game_min_port'] ?> - <?php echo $item['game_max_port'] ?></td>
							<td><?php echo $item['game_price'] ?> руб.</td>
							<td><button type="button" class="btn btn-xs bg-purple" onClick="redirect('/admin/games/edit/index/<?php echo $item['game_id'] ?>')">Редактирование игры</button></td>
						</tr>
						<?php endforeach; ?>
						<?php if(empty($games)): ?>
						<tr>
							<td colspan="8" class="text-center">На данный момент нет игр.</td>
						<tr>
						<?php endif; ?>
					</tbody>
				</table>
			</div>
			<ul class="pagination pull-right">
				<?php echo $pagination ?>
			</ul>
		</div>
		<a href="/admin/games/create" class="btn btn-sm btn-azure">Создать игру</a>
	</div>
</div>
<?php echo $footer ?>