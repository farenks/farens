<?php echo $admheader ?>
<div class="row">
	<div class="col-md-12">
		<div class="content-box">
			<h3 class="content-box-header bg-default">Все пользователи</h3>
			<div class="content-box-wrapper">
				<table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered">
					<thead>
						<tr>
							<th>ID</th>
							<th>Статус</th>
							<th>Имя</th>
							<th>Фамилия</th>
							<th>E-Mail</th>
							<th>Дата регистрации</th>
							<th>Действия</th>
						</tr>
					</thead>
					<tbody>
						<?php foreach($users as $item): ?>
						<tr>
							<td>#<?php echo $item['user_id'] ?></td>
							<td>
								<?php if($item['user_status'] == 0): ?>
								<span class="bs-label label-danger">Заблокирован</span>
								<?php elseif($item['user_status'] == 1): ?>
								<span class="bs-label label-success">Активен</span>
								<?php endif; ?>
							</td>
							<td><?php echo $item['user_firstname'] ?></td>
							<td><?php echo $item['user_lastname'] ?></td>
							<td><?php echo $item['user_email'] ?></td>
							<td><?php echo date("d.m.Y", strtotime($item['user_date_reg'])) ?></td>
							<td><button type="button" class="btn btn-xs bg-purple" onClick="redirect('/admin/users/edit/index/<?php echo $item['user_id'] ?>')">Редактирование пользователя</button></td>
						</tr>
						<?php endforeach; ?>
						<?php if(empty($users)): ?>
						<tr>
							<td colspan="7" style="text-align: center;">На данный момент нет пользователей.</td>
						<tr>
						<?php endif; ?>
					</tbody>
				</table>
			</div>
			<ul class="pagination pull-right">
				<?php echo $pagination ?>
			</ul>
		</div>
	</div>
</div>
<?php echo $footer ?>