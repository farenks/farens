<?php echo $header ?>
<div class="row"> <h3 class="content-box-header bg-blue">Выберите платежку и пополните баланс</h3><br>
<?if($payok == 1):?>
<div class="col-md-6">
               <div class="content-box">
                  <h3 class="content-box-header bg-blue">PayOK</h3>
                  <div class="content-box-wrapper">
					<div class="form-horizontal">
						<div class="form-group">
						<center><img src="/application/public/img/pay/payok.svg"></center><br>
							<div class="col-sm-offset-4 col-sm-9">
								<button data-toggle="modal" data-target="#payok" class="button1 primary">Пополнить</button>
							</div>
						</div>
					</div>
                  </div>
               </div>
            </div>
<?endif;?>
</div>
<div class="modal fade" id="payok" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
					<div class="modal-dialog" role="document">
						<div class="modal-content">
							<div class="modal-header">
								<h5 class="modal-title" id="exampleModalLabel">Пополнение баланса</h5>
								<button type="button" class="close" data-dismiss="modal" aria-label="Close">
								<i aria-hidden="true" class="ki ki-close"></i>
								</button>
							</div>
							<form id="payok" method="POST" class="form_0" style="padding:0px; margin:0px;">
								<div class="modal-body">
									<div class="form-group">
										<label>Введите сумму</label>
										<input class="form-control" id="ammount" name="ammount" placeholder="100">
									</div>
								</div>
								<div class="modal-footer">
									<button type="button" class="btn btn-light-primary font-weight-bold" data-dismiss="modal">Отмена</button>
									<button type="submit" class="btn btn-primary font-weight-bold">Пополнить</button>
								</div>
							</form>
						</div>
					</div>
				</div>
				
<script>
	$('#payok').ajaxForm({ 
	     url: '/account/payok/ajax',
	     dataType: 'text',
	     success: function(data) {
	         console.log(data);
	         data = $.parseJSON(data);
	         switch(data.status) {
	             case 'error':
	                 toastr.error(data.error);
	                 $('button[type=submit]').prop('disabled', false);
	                 break;
	             case 'success':
	                 redirect(data.url);
	             break;
	         }
	     },
	     beforeSubmit: function(arr, $form, options) {
	         $('button[type=submit]').prop('disabled', true);
	     }
	 });
</script>

<?php echo $footer ?>