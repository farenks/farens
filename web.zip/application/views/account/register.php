<?php echo $loginheader ?>
<div class="center-content">
	<form action="#" id="registerForm" class="col-md-5 col-sm-5 col-xs-11 center-margin" method="post">
		<h3 class="text-center pad25B font-white font-size-23">
		<span class="opacity-80">Панель управления серверами<br></span>
			<center><h2 class="opacity-80">AquzaPL</h2><br></center>
		</h3>
		<div id="login-form" class="content-box">
			<div class="content-box-wrapper pad20A">
				<div class="form-group">
					<div class="input-group input-group-lg">
						<span class="input-group-addon addon-inside bg-white font-primary">
						<i class="glyph-icon icon-linecons-user"></i>
						</span>
						<input type="text" class="form-control" type="text" id="ref" name="ref" disabled placeholder="<?php
                                       if(isset($_GET['ref'])) {
                                           echo 'Приглашение от ID-'.$_GET['ref'].'';
                                       }else echo ' Без приглашения';
                                       ?>">
						<input type="hidden" name="ref" id="ref" value="<?echo $_GET['ref']?>">
					</div>
				</div>
				<div class="form-group">
					<div class="input-group input-group-lg">
						<span class="input-group-addon addon-inside bg-white font-primary">
						<i class="glyph-icon icon-linecons-user"></i>
						</span>
						<input type="text" class="form-control" id="firstname" name="firstname" placeholder="Имя">
					</div>
				</div>
				<div class="form-group">
					<div class="input-group input-group-lg">
						<span class="input-group-addon addon-inside bg-white font-primary">
						<i class="glyph-icon icon-linecons-user"></i>
						</span>
						<input type="text" class="form-control" id="lastname" name="lastname" placeholder="Фамилия">
					</div>
				</div>
				<div class="form-group">
					<div class="input-group input-group-lg">
						<span class="input-group-addon addon-inside bg-white font-primary">
						<i class="glyph-icon icon-linecons-mail"></i>
						</span>
						<input type="text" class="form-control" id="email" name="email" placeholder="E-Mail">
					</div>
				</div>
				<div class="form-group">
					<div class="input-group input-group-lg">
						<span class="input-group-addon addon-inside bg-white font-primary">
						<i class="glyph-icon icon-linecons-key"></i>
						</span>
						<input type="password" class="form-control" id="password" name="password" placeholder="Пароль">
					</div>
				</div>
				<div class="form-group">
					<div class="input-group input-group-lg">
						<span class="input-group-addon addon-inside bg-white font-primary">
						<i class="glyph-icon icon-linecons-key"></i>
						</span>
						<input type="password" class="form-control" id="password2" name="password2" placeholder="Повтор пароля">
					</div>
				</div>
				
				<div class="recaptcha"> 
				<center><div class="g-recaptcha" data-sitekey="<?php echo $recaptcha ?>"></div></center>
			   </div>
				
			</div>
			<div class="button-pane">
				<button type="submit" class="button1 success" data-hover="Зарегистрироваться">Зарегистрироваться</button>
				<a class="button1 primary" data-hover="Авторизация" href="/account/login">Авторизация</a>
				<a class="button1 info" data-hover="Восстановить пароль" href="/account/restore">Восстановить пароль</a>
			</div>
		</div>
	</form>
</div>

<script src='https://www.google.com/recaptcha/api.js'></script>

<script>
	$('#registerForm').ajaxForm({ 
		url: '/account/register/ajax',
		dataType: 'text',
		success: function(data) {
			console.log(data);
			data = $.parseJSON(data);
			switch(data.status) {
				case 'error':
					//showError(data.error);
					swal("Ошибка", data.error, "error");
					//$.jGrowl(data.error, { sticky: !1, position: "top-right", theme: "bg-red" });
					reloadImage('.captcha img');
					$('button[type=submit]').prop('disabled', false);
					break;
				case 'success':
					//showSuccess(data.success);
					swal("Успешно", data.success, "success");
					//$.jGrowl(data.success, { sticky: !1, position: "top-right", theme: "bg-green" });
					setTimeout("redirect('/')", 1500);
					break;
			}
		},
		beforeSubmit: function(arr, $form, options) {
			$('button[type=submit]').prop('disabled', true);
		}
	});
	$('.captcha img').click(function() {
		reloadImage(this);
	});
</script>
<?php echo $loginfooter ?>