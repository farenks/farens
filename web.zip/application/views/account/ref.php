﻿<?php echo $header ?>
<div class="row">
	<div class="col-md-12">
		<div class="content-box">
			<h3 class="content-box-header bg-default">Реферальная программа</h3>
			<div class="content-box-wrapper">
				<table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered">
					<thead>
						<tr>
							<th>ID</th>
							<th>Имя</th>
							<th>Фамилия</th>
							<th>Заработал</th>
						</tr>
					</thead>
					<tbody>
						<?php foreach($userg as $item):?>
						<? if (!($item['ref'] == $_SESSION['user_id'])) { // пропуск нечетных чисел
							continue;
						}?>
						<tr>
							<td><?php echo $item['user_id'] ?></td>
							<td><?php echo $item['user_firstname'] ?></td>
							<td><?php echo $item['user_lastname'] ?></td>
							<td><?php echo $item['rmoney'] ?></td>
						</tr>
						<?php endforeach; ?>
						<?$ust = 0;
						foreach($userg as $item): ?>
						<? if (!($item['ref'] == $_SESSION['user_id'])) { // пропуск нечетных чисел
						continue;
						}?>
						<? $ust++; ?>
						<?endforeach; ?>
						<?php if(empty($ust)): ?> 
						<tr>
							<td colspan="4" style="text-align: center;">У вас нет рефералов.</td>
						</tr>
						<?php endif; ?>
						<tr><td colspan="4"><b><center>Ссылка для привлечения: <code>http://<?echo $_SERVER['SERVER_NAME']?>/account/register?ref=<?php echo $user['id'] ?></code></td></tr>
						<tr><td colspan="4"><b><center>За каждого нового клиента, которого вы пригласите, вы будете получать 30% от суммы его заказов и пополнений</center></b></td></tr>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>
<?php echo $footer ?>