﻿<?php echo $header ?>
<div class="row">
		<div class="content-box">
			<h3 class="content-box-header bg-default">Перевод средств</h3>
			<div class="content-box-wrapper">
				<form class="form-horizontal" action="#" id="payForm" method="POST">
					<div class="form-group">
						<div class="col-sm-12">
							<input type="text" class="form-control" id="userid" name="userid" placeholder="ID Пользователя">
						</div>
					</div>
					<div class="form-group">
						<div class="col-sm-12">
							<input type="text" class="form-control" id="sum" name="sum" placeholder="Сумма">
						</div>
					</div>
					<div class="form-group">
						<div class="col-sm-offset-12 col-sm-9">
							<button type="submit" class="button1 primary" data-hover="">Перевести средства</button>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>
<script>
	$('#payForm').ajaxForm({ 
		url: '/account/perevod/ajax',
		dataType: 'text',
		success: function(data) {
			console.log(data);
			data = $.parseJSON(data);
			switch(data.status) {
				case 'error':
					//showError(data.error);
					$.jGrowl(data.error, { sticky: !1, position: "top-right", theme: "bg-red" });
					break;
				case 'success':
					//showSuccess(data.success);
					$.jGrowl(data.success, { sticky: !1, position: "top-right", theme: "bg-green" });
					setTimeout("redirect('/account/perevod')", 1500);
					break;
			}
		},
		beforeSubmit: function(arr, $form, options) {
			$('button[type=submit]').prop('disabled', true);
			showWarning("Вы успешно перевели деньги");
		}
	});
</script>
<?php echo $footer ?>
