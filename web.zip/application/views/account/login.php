<?php echo $loginheader ?>
<div class="center-content">
	<form action="#" id="loginForm" class="col-md-5 col-sm-5 col-xs-11 center-margin" method="post">
		<h3 class="text-center pad25B font-gray font-size-23">AquzaPL<br><span class="opacity-80">Панель управления серверами</span></h3>
		<div id="login-form" class="content-box">
			<div class="content-box-wrapper pad20A">
				<div class="form-group">
					<div class="input-group input-group-lg">
						<span class="input-group-addon addon-inside bg-white font-primary">
						<i class="glyph-icon icon-linecons-mail"></i>
						</span>
						<input type="text" class="form-control" id="email" name="email" placeholder="E-Mail">
					</div>
				</div>
				<div class="form-group">
					<div class="input-group input-group-lg">
						<span class="input-group-addon addon-inside bg-white font-primary">
						<i class="glyph-icon icon-linecons-key"></i>
						</span>
						<input type="password" class="form-control" id="password" name="password" placeholder="Пароль">
					</div>
				</div>
				
			   <div class="recaptcha"> 
				<center><div class="g-recaptcha" data-sitekey="<?php echo $recaptcha ?>"></div></center>
			   </div>
				
			</div>
			<div class="button-pane">
				<button type="submit" class="button1 success" data-hover="Вход">Вход</button>
				<a class="button1 primary" data-hover="Регистрация" href="/account/register">Регистрация</a>
				<a class="button1 info" data-hover="Восстановить пароль" href="/account/restore">Восстановить пароль</a>
			</div>
		</div>
	</form>
</div>

<script src='https://www.google.com/recaptcha/api.js'></script>

<script>
	$('#loginForm').ajaxForm({ 
		url: '/account/login/ajax',
		dataType: 'text',
		success: function(data) {
			console.log(data);
			data = $.parseJSON(data);
			switch(data.status) {
				case 'error':
					//showError(data.error);
					swal("Ошибка", data.error, "error");
					//$.jGrowl(data.error, { sticky: !1, position: "top-right", theme: "bg-red" });
					$('button[type=submit]').prop('disabled', false);
					break;
				case 'success':
					//showSuccess(data.success);
					swal("Успешно", data.success, "success");
					//$.jGrowl(data.success, { sticky: !1, position: "top-right", theme: "bg-green" });
					if(data.url){
						//setTimeout("redirect("+data.url+")", 1500);
						setTimeout("redirect("+data.url+")", 1500);
					}else{
						setTimeout("redirect('/')", 1500);
					}
					//setTimeout("redirect('/')", 1500);
					break;
			}
		},
		beforeSubmit: function(arr, $form, options) {
			$('button[type=submit]').prop('disabled', true);
		}
	});
</script>
<?php echo $loginfooter ?>