<?php echo $header ?>
<div class="row">
<div id="page-title">
	<h2>Вы вошли как <?php echo $user_firstname ?> <?php echo $user_lastname ?></h2>
	<p>ID - <?php echo $user_id ?>. Почта - <?php echo $user_email ?></p>
</div>

<div class="col-md-12">
				<div class="content-box pad20A">
					<center>
						<h3>Ваш баланс: <?php echo $user_balance;?> руб.</h3><br>
						<hr>
						<a class="btn btn-xs bg-purple" href="/account/pay">Пополнить баланс</a>
					</center>
				</div>
			
			</div>
</div>
<div class="col-md-12">
	<div class="panel panel-default">
		<div class="panel-heading">Мы в Вконтакте</div>
		<div class="tab-container">
            <div class="tab-content">
                <div class="tab-pane cont active">
				   <div id="vk_widget" style="width: 100%;"><div id="vk_groups" style="width: 282px; height: 400px; background: none;"><iframe name="fXDf17ad" frameborder="0" src="" width="282" height="400" scrolling="no" id="vkwidget3" style="overflow: hidden; height: 400px;"></iframe></div></div>
				   <script type="text/javascript" src="//vk.com/js/api/openapi.js?136"></script>
				   <script !src="">
						 function VK_Widget_Init(){
							  var getWidth = document.getElementById("vk_widget").clientWidth;
							  console.log(getWidth);
							  document.getElementById('vk_widget').innerHTML = '<div id="vk_groups"></div>';
							  VK.Widgets.Group("vk_groups", {
								   mode: 4,
								   color2: '37474F',
								   width: getWidth,
								   height: "400",
							   }, <?php echo $public ?>);
						 };
						 window.addEventListener('load', VK_Widget_Init, false);
						 window.addEventListener('resize', VK_Widget_Init, false);
				   </script>
				</div>
            </div>
        </div>
    </div>
</div>
<?php echo $footer ?>