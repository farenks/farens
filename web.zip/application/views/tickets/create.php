<?php echo $header ?>
<div class="row">
	<div class="col-md-12">
		<div class="content-box">
			<h3 class="content-box-header bg-default">Создать запрос</h3>
			<div class="content-box-wrapper">
				<form class="form-horizontal" action="#" id="createForm" method="POST">
					<div class="form-group">
						<label for="text" class="col-sm-4 control-label">Тема:</label>
						<div class="col-sm-5">
							<input type="text" class="form-control" id="name" name="name" placeholder="Введите тему">
						</div>
					</div>
					<div class="form-group">
						<label for="text" class="col-sm-4 control-label">Сообщение:</label>
						<div class="col-sm-5">
							<textarea class="form-control" id="text" name="text" rows="7"></textarea>
						</div>
					</div>
					<div class="form-group">
						<div class="col-sm-offset-4 col-sm-9">
							<button type="submit" class="btn btn-primary">Создать</button>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>
<script>
	$('#createForm').ajaxForm({ 
		url: '/tickets/create/ajax',
		dataType: 'text',
		success: function(data) {
			console.log(data);
			data = $.parseJSON(data);
			switch(data.status) {
				case 'error':
					//showError(data.error);
					$.jGrowl(data.error, { sticky: !1, position: "top-right", theme: "bg-red" });
					$('button[type=submit]').prop('disabled', false);
					break;
				case 'success':
					//showSuccess(data.success);
					$.jGrowl(data.success, { sticky: !1, position: "top-right", theme: "bg-green" });
					setTimeout("redirect('/tickets/view/index/" + data.id + "')", 1500);
					break;
			}
		},
		beforeSubmit: function(arr, $form, options) {
			$('button[type=submit]').prop('disabled', true);
		}
	});
</script>
<?php echo $footer ?>