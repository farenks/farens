<?php
/*
Copyright (c) 2019 HOSTINPL (HOSTING-RUS) https://vk.com/hosting_rus
Developed by Samir Shelenko (https://vk.com/id00v)
*/
class autoModel extends Model {
	public function createAuto($data) {
		
		$sql = "INSERT INTO `servers_auto` SET ";
		$sql .= "`auto_url` = '" . $data['auto_url'] . "', ";
		$sql .= "`auto_name` = '" . $data['auto_name'] . "', ";
		$sql .= "`auto_price` = '" . $data['auto_price'] . "', ";
		$sql .= "`game_id` = '" . (int)$data['game_id'] . "', ";
		$sql .= "`auto_act` = '" . (int)$data['auto_act'] . "', ";
		$sql .= "`auto_status` = '" . (int)$data['auto_status'] . "', ";
		$sql .= "`auto_arch` = '" . $data['auto_arch'] . "', ";
		$sql .= "`auto_textx` = '" . strip_tags(htmlspecialchars_decode($this->db->escape($data['auto_textx'])), '<img><span><ul><ol><pre><li><div><em><strong><sup><code>') . "', ";
		$sql .= "`auto_img` = '" . $data['auto_img'] . "'";
		$this->db->query($sql);
		$return=$this->db->getLastId();		
		return $return;
	}


	public function deleteAuto($autoid) {
		$sql = "DELETE FROM `servers_auto` WHERE auto_id = '" . (int)$autoid . "'";
		$this->db->query($sql);
	}
	
	public function blockAuto($autoid) {
		$sql = "DELETE FROM `servers_auto` WHERE auto_id = '" . (int)$autoid . "'";
		$this->db->query($sql);
	}
	
	public function updateAuto($autoid, $data = array()) {
		$sql = "UPDATE `servers_auto`";
		if(!empty($data)) {
			$count = count($data);
			$sql .= " SET";
			foreach($data as $key => $value) {
				$sql .= " $key = '" . $this->db->escape($value) . "'";
				
				$count--;
				if($count > 0) $sql .= ",";
			}
		}
		$sql .= " WHERE `auto_id` = '" . (int)$autoid . "'";
		$query = $this->db->query($sql);
	}
	public function getAutos($data = array(), $joins = array(),$sort = array(), $options = array()) {
		$sql = "SELECT * FROM `servers_auto`";
		foreach($joins as $join) {
			$sql .= " LEFT JOIN $join";
			switch($join) {
				case "games":
					$sql .= " ON servers_auto.game_id=games.game_id";
					break;
			}
		}
		if(!empty($data)) {
			$count = count($data);
			$sql .= " WHERE";
			foreach($data as $key => $value) {
				$sql .= " $key = '" . $this->db->escape($value) . "'";
				
				$count--;
				if($count > 0) $sql .= " AND";
			}
		}
		
		if(!empty($sort)) {
			$count = count($sort);
			$sql .= " ORDER BY";
			foreach($sort as $key => $value) {
				$sql .= " $key " . $value;
				
				$count--;
				if($count > 0) $sql .= ",";
			}
		}
		
		if(!empty($options)) {
			if ($options['start'] < 0) {
				$options['start'] = 0;
			}
			if ($options['limit'] < 1) {
				$options['limit'] = 20;
			}
			$sql .= " LIMIT " . (int)$options['start'] . "," . (int)$options['limit'];
		}
		$query = $this->db->query($sql);
		return $query->rows;
	}
	 
	public function getAutoById($autoid, $joins = array()) {
		$sql = "SELECT * FROM `servers_auto`";
		foreach($joins as $join) {
			$sql .= " LEFT JOIN $join";
			switch($join) {
				case "games":
					$sql .= " ON servers_auto.game_id=games.game_id";
					break;
			}
		}
		$sql .=  " WHERE `auto_id` = '" . (int)$autoid . "' LIMIT 1";
		$query = $this->db->query($sql);
		return $query->row;
	}
	
	public function getTotalAutos($data = array()) {
		$sql = "SELECT COUNT(*) AS count FROM `servers_auto`";
		if(!empty($data)) {
			$count = count($data);
			$sql .= " WHERE";
			foreach($data as $key => $value) {
				$sql .= " $key = '" . $this->db->escape($value) . "'";
				
				$count--;
				if($count > 0) $sql .= " AND";
			}
		}
		$query = $this->db->query($sql);
		return $query->row['count'];
	}
}
?>
