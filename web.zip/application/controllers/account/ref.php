<?php
/*
* @LitePanel
* @Developed by QuickDevel
*/
class refController extends Controller {
	public function index() {
		$this->document->setActiveSection('account');
		$this->document->setActiveItem('edit');
		
		if(!$this->user->isLogged()) {
			$this->session->data['error'] = "Вы не авторизированы!";
			$this->response->redirect($this->config->url . 'account/login');
		}
		if($this->user->getAccessLevel() < 0) {
			$this->session->data['error'] = "У вас нет доступа к данному разделу!";
			$this->response->redirect($this->config->url);
		}
		
		$this->load->model('users');

		$userData = array(
			'id' => $this->user->getId()
		);

		$options = array(
			'start' => 0,
			'limit' => 1000
		);
		
		$users = $this->usersModel->getUsers(array(), array(), $options);
		$this->data['users'] = $users;		
		$this->data['user'] = $userData;
		
		$userg = $this->usersModel->getUsers(array('servers'), array(), array());
		$this->data['userg'] = $userg;
		
		$this->getChild(array('common/header', 'common/footer'));
		return $this->load->view('account/ref', $this->data);
	}
}
?>
