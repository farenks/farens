﻿<?php
class payokController extends Controller {
	public function index() {
		$this->load->model('users');
		$this->load->model('invoices');
		
		if($this->request->server['REQUEST_METHOD'] == 'POST') {
			$errorPOST = $this->validatePOST();
			if(!$errorPOST) {
				$ammount = $this->request->post['amount'];
				$invid = $this->request->post['payment_id'];
				$signature = $this->request->post['sign'];
				
				$invoice = $this->invoicesModel->getInvoiceById($invid);
				if($invoice['invoice_status'] == 0) {
					$userid = $invoice['user_id'];
					$user = $this->usersModel->getUserById($userid);
					
					$this->usersModel->upUserBalance($userid, $ammount);

					$this->invoicesModel->updateInvoice($invid, array('invoice_status' => 1));
					return "OK$invid\n";
				} else {
					return "ERROR PAY$invid\n";
				}
			} else {
				return "Error: $errorPOST";
			}
		} else {
			return "Error: Invalid request!";
		}
	}
	
	private function validatePOST() {
		$result = null;
		
		$ammount = $this->request->post['amount'];
		$invid = $this->request->post['payment_id'];
		$signature = $this->request->post['sign'];
		$currency = $this->request->post['currency'];
		$desc = $this->request->post['desc'];
		
		$login = $this->config->payok_id;
		$password = $this->config->payok_key;
		
		$array_sign = array (
			$password,
			'desc' => $desc,
			'currency' => $currency,
			'shop' => $login,
			'payment_id' => $invid,
			'amount' => $ammount
		); 
		$sign_create = md5(implode('|', $array_sign)); 
		
		if(!$this->invoicesModel->getTotalInvoices(array('invoice_id' => (int)$invid))) {
			$result = "Invalid invoice!";
		}
        elseif(strtoupper($signature) != strtoupper($sign_create)) {
			$result = "Invalid signature!";
		}
		return $result;
	}
}
?>
