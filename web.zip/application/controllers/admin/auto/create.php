<?php
class createController extends Controller {
	public function index() {
		$this->document->setActiveSection('admin');
		$this->document->setActiveItem('locations');
		
		if(!$this->user->isLogged()) {
			$this->session->data['error'] = "Вы не авторизированы!";
			$this->response->redirect($this->config->url . 'account/login');
		}
		if($this->user->getAccessLevel() < 3) {
			$this->session->data['error'] = "У вас нет доступа к данному разделу!";
			$this->response->redirect($this->config->url);
		}
		$this->load->model('games');
		$options = array(
			'start' => ($page - 1) * $this->limit,
			'limit' => $this->limit
		);
		$games = $this->gamesModel->getGames(array(), array(), $options);
		$this->data['games'] = $games;
		$this->getChild(array('common/admheader', 'common/footer'));
		return $this->load->view('admin/auto/create', $this->data);
	}
	
	public function ajax() {
		if(!$this->user->isLogged()) {  
	  		$this->data['status'] = "error";
			$this->data['error'] = "Вы не авторизированы!";
			return json_encode($this->data);
		}
		if($this->user->getAccessLevel() < 3) {
			$this->data['status'] = "error";
			$this->data['error'] = "У вас нет доступа к данному разделу!";
			return json_encode($this->data);
		}
		
		$this->load->model('auto');
		
		if($this->request->server['REQUEST_METHOD'] == 'POST') {
			$errorPOST = $this->validatePOST();
			if(!$errorPOST) {
				$name = @$this->request->post['name'];
				$gameid = @$this->request->post['gameid'];
				$arch = @$this->request->post['arch'];
				$act = @$this->request->post['act'];
				$textx = @$this->request->post['textx'];
				$img = @$this->request->post['img'];
				$status = @$this->request->post['status'];
				$price = @$this->request->post['price'];
				$url = @$this->request->post['url'];
				$arch = @$this->request->post['arch'];
				
				if($act) {
					$autoData = array(
						'game_id'			=> $gameid,
						'auto_name'			=> $name,
						'auto_url'			=> $url,
						'auto_status'		=> (int)$status,
						'auto_textx'			=> $textx,
						'auto_img'	     	=> $img,
						'auto_arch'		    => $arch,
						'auto_price'	    	=> $price,
						'auto_act'			=> 2
					);
					$this->autoModel->createAuto($autoData);				
					$this->data['status'] = "success";
					$this->data['success'] = "Вы успешно создали мод!";
				} else {
					$autoData = array(
						'game_id'			=> $gameid,
						'auto_name'			=> $name,
						'auto_url'			=> $url,
						'auto_status'		=> (int)$status,
						'auto_textx'			=> $textx,
						'auto_img'	     	=> $img,
						'auto_arch'		    => $arch,
						'auto_price'			=> 0,
						'auto_act'	   	    => 1
					);
					$this->autoModel->createAuto($autoData);		
					$this->data['status'] = "success";
					$this->data['success'] = "Вы успешно создали мод!";
				}
			} else {
				$this->data['status'] = "error";
				$this->data['error'] = $errorPOST;
			}
		}

		return json_encode($this->data);
	}
	
	private function validatePOST() {
		$this->load->library('validate');
		
		$validateLib = new validateLibrary();
		
		$result = null;
		
		$name = @$this->request->post['name'];
		$gameid = @$this->request->post['gameid'];
		$arch = @$this->request->post['arch'];
		$status = @$this->request->post['status'];
		$textx = @$this->request->post['textx'];
		$price = @$this->request->post['price'];
		$act = @$this->request->post['act'];
		
		if(mb_strlen($name) < 2 || mb_strlen($name) > 32) {
			$result = "Название дополнения должно содержать от 2 до 32 символов!";
		}
		elseif(mb_strlen($textx) < 2 || mb_strlen($textx) > 9900) {
			$result = "Описание должно содержать от 2 до 100 символов!";
		}
		elseif($status < 0 || $status > 1) {
			$result = "Укажите допустимый статус!";
		}
		elseif($act) {
			if(1 > $price || $price > 5000) {
				$result = "Укажите сумму от 1 до 5000 рублей!";
			}
		}
		return $result;
	}
}
?>
