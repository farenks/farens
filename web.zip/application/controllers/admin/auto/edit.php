<?php
class editController extends Controller {
	public function index($autoid = null) {
 
		if(!$this->user->isLogged()) {
			$this->session->data['error'] = "Вы не авторизированы!";
			$this->response->redirect($this->config->url . 'account/login');
		}
		if($this->user->getAccessLevel() < 3) {
			$this->session->data['error'] = "У вас нет доступа к данному разделу!";
			$this->response->redirect($this->config->url);
		}
		
		$this->load->model('auto');
		
		$error = $this->validate($autoid);
		if($error) {
			$this->session->data['error'] = $error;
			$this->response->redirect($this->config->url . 'admin/auto/index');
		}
		
		$auto = $this->autoModel->getAutoById($autoid);
		
		$this->data['auto'] = $auto;
		$this->load->model('games');
		$options = array(
			'start' => ($page - 1) * $this->limit,
			'limit' => $this->limit
		);
		$games = $this->gamesModel->getGames(array(), array(), $options);
		$this->data['games'] = $games;
		$this->getChild(array('common/admheader', 'common/footer'));
		return $this->load->view('admin/auto/edit', $this->data);
	}
	
	public function ajax($autoid = null) {
		if(!$this->user->isLogged()) {  
	  		$this->data['status'] = "error";
			$this->data['error'] = "Вы не авторизированы!";
			return json_encode($this->data);
		}
		if($this->user->getAccessLevel() < 3) {
			$this->data['status'] = "error";
			$this->data['error'] = "У вас нет доступа к данному разделу!";
			return json_encode($this->data);
		}
		
		$this->load->model('auto');
		
		$error = $this->validate($autoid);
		if($error) {
			$this->data['status'] = "error";
			$this->data['error'] = $error;
			return json_encode($this->data);
		}
		
		if($this->request->server['REQUEST_METHOD'] == 'POST') {
			$errorPOST = $this->validatePOST();
			if(!$errorPOST) {
				$gameid = @$this->request->post['gameid'];
				$name = @$this->request->post['name'];
				$url = @$this->request->post['url'];
				$status = @$this->request->post['status'];
				$textx = @$this->request->post['textx'];
				$img = @$this->request->post['img'];
				$arch = @$this->request->post['arch'];
				$price = @$this->request->post['price'];
				$act = @$this->request->post['act'];
			
				if($act) {
					$autoData = array(
						'game_id'			=> $gameid,
						'auto_name'			=> $name,
						'auto_url'			=> $url,
						'auto_status'		=> (int)$status,
						'auto_textx'			=> $textx,
						'auto_img'	     	=> $img,
						'auto_arch'		    => $arch,
						'auto_price'	    	=> $price,
						'auto_act'			=> 2
					);
					$this->autoModel->updateAuto($autoid, $autoData);				
					$this->data['status'] = "success";
					$this->data['success'] = "Вы успешно отредактировали мод!";
				} else {
					$autoData = array(
						'game_id'			=> $gameid,
						'auto_name'			=> $name,
						'auto_url'			=> $url,
						'auto_status'		=> (int)$status,
						'auto_textx'			=> $textx,
						'auto_img'	     	=> $img,
						'auto_arch'		    => $arch,
						'auto_price'			=> 0,
						'auto_act'	   	    => 1
					);
					$this->autoModel->updateAuto($autoid, $autoData);		
					$this->data['status'] = "success";
					$this->data['success'] = "Вы успешно отредактировали мод!";
				}
			} else {
				$this->data['status'] = "error";
				$this->data['error'] = $errorPOST;
			}
		}

		return json_encode($this->data);
	}
	
	public function delete($autoid = null) {
		$this->document->setActiveSection('admin');
		$this->document->setActiveItem('auto');
		
		if(!$this->user->isLogged()) {
			$this->session->data['error'] = "Вы не авторизированы!";
			$this->response->redirect($this->config->url . 'account/login');
		}
		if($this->user->getAccessLevel() < 3) {
			$this->session->data['error'] = "У вас нет доступа к данному разделу!";
			$this->response->redirect($this->config->url);
		}
		
		$this->load->model('auto');
		
		$error = $this->validate($autoid);
		if($error) {
			$this->session->data['error'] = $error;
			$this->response->redirect($this->config->url . 'admin/auto/index');
		}
		
		$this->autoModel->deleteAuto($autoid);
		
		$this->session->data['success'] = "Вы успешно удалили мод!";
		$this->response->redirect($this->config->url . 'admin/auto/index');
		return null;
	}
	
	private function validate($autoid) {
		$result = null;
		
		if(!$this->autoModel->getTotalAutos(array('auto_id' => (int)$autoid))) {
			$result = "Запрашиваемый мод не существует!";
		}
		return $result;
	}
	
	private function validatePOST() {
		$this->load->library('validate');
		
		$validateLib = new validateLibrary();
		
		$result = null;
		
		$gameid = @$this->request->post['gameid'];
		$url = @$this->request->post['url'];
		$arch = @$this->request->post['arch'];
		$name = @$this->request->post['name'];
		$status = @$this->request->post['status'];
		$textx = @$this->request->post['textx'];
		$img = @$this->request->post['img'];
		$price = @$this->request->post['price'];
		
		if(mb_strlen($name) < 2 || mb_strlen($name) > 32) {
			$result = "Название мода должно содержать от 2 до 32 символов!";
		}
		elseif($act) {
			if(1 > $price || $price > 5000) {
				$result = "Укажите сумму от 1 до 5000 рублей!";
			}
		}
		elseif(mb_strlen($textx) < 2 || mb_strlen($textx) > 9900) {
			$result = "Описание должно содержать от 2 до 100 символов!";
		}
		return $result;
	}
}
?>
