<?php
/*
Copyright (c) 2020 HOSTINPL (HOSTING-RUS) https://vk.com/hosting_rus
Developed by Samir Shelenko (https://vk.com/id00v)
*/
class indexController extends Controller {
	public function index() {
		$this->document->setActiveSection('admin');
		$this->document->setActiveItem('index');
		
		if(!$this->user->isLogged()) {
			$this->response->redirect($this->config->url . 'account/login');
		}
		if($this->user->getAccessLevel() < 2) {
			$this->session->data['error'] = "У вас нет доступа к данному разделу!";
			$this->response->redirect($this->config->url);
		}
		
		$this->load->model('servers');
		$this->load->model('users');
		$this->load->model('invoices');
		$this->load->model('games');
		$this->load->model('tickets');
		
		$total = $this->ticketsModel->getTotalTickets($getData);
		$tickets = $this->ticketsModel->getTickets($getData, array('users'), $getSort, $getOptions);
		$tservers = $this->serversModel->getServers($getData, array('games', 'locations'), array(), $getOptions);
		$total = $this->invoicesModel->getTotalInvoices($getData);
		$invoices = $this->invoicesModel->getInvoices($getData, array('users'), array(), $options);
		$servers = $this->serversModel->getServers(array('user_id' => (int)$userid), array('games', 'locations'), array(), $options);
		$users = $this->usersModel->getUsers(array(), array(), $options);
		
		$userid = $this->user->getId();
		
		$this->data['games'] = $games;
		$this->data['users'] = $users;
		$this->data['tservers'] = $tservers;
		$this->data['servers'] = $servers;
		$this->data['invoices'] = $invoices;		
		$this->data['tickets'] = $tickets;		
		
		$this->data['logged'] = true;
		$this->data['user_email'] = $this->user->getEmail();
		$this->data['user_firstname'] = $this->user->getFirstname();
		$this->data['user_lastname'] = $this->user->getLastname();
		$this->data['user_balance'] = $this->user->getBalance();
				
		$this->getChild(array('common/admheader', 'common/footer'));
		return $this->load->view('admin/index', $this->data);
	}
}
?>