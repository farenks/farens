<?php
/*
* @LitePanel
* @Developed by QuickDevel
*/
class autoinstallController extends Controller {
	public function index($serverid = null) {
		$this->document->setActiveSection('servers');
		$this->document->setActiveItem('index');
		
		if(!$this->user->isLogged()) {
			$this->session->data['error'] = "Вы не авторизированы!";
			$this->response->redirect($this->config->url . 'account/login');
		}
		if($this->user->getAccessLevel() < 0) {
			$this->session->data['error'] = "У вас нет доступа к данному разделу!";
			$this->response->redirect($this->config->url);
		}
		
		$this->load->library('query');
		$this->load->model('servers');
		$this->load->model('auto');
		
		$error = $this->validate($serverid);
		if($error) {
			$this->session->data['error'] = $error;
			$this->response->redirect($this->config->url . 'servers/index');
		}
		
		$userid = $this->user->getId();

		$total = $this->autoModel->getTotalAutos();
		$auto = $this->autoModel->getAutos(array('auto_status' => 1),array('games'),array(), $options);
		$this->data['auto'] = $auto;
		
		$server = $this->serversModel->getServerById($serverid, array('games', 'locations'));
		$this->data['server'] = $server;
		
		if($server['server_status'] == 2) {
			$queryLib = new queryLibrary($server['game_query']);
			$queryLib->connect($server['location_ip'], $server['server_port']);
			$query = $queryLib->getInfo();
			$queryLib->disconnect();
			
			$this->data['query'] = $query;
		}
		

		
		$this->getChild(array('common/header', 'common/footer'));
		return $this->load->view('servers/autoinstall', $this->data);
	}
	
	public function action($serverid = null, $action = null) {
		if(!$this->user->isLogged()) {
			$this->data['status'] = "error";
			$this->data['error'] = "Вы не авторизированы!";
			return json_encode($this->data);
		}
		if($this->user->getAccessLevel() < 0) {
	  		$this->data['status'] = "error";
			$this->data['error'] = "У вас нет доступа к данному разделу!";
			return json_encode($this->data);
		}
		$userid = $this->user->getId();
		$this->load->model('servers');
		$this->load->library('ssh2');
		$this->load->model('auto');
		$this->load->model('users');
		$ssh2Lib = new ssh2Library();
		
		$error = $this->validate($serverid);
		if($error) {
			$this->data['status'] = "error";
			$this->data['error'] = $error;
			return json_encode($this->data);
		}	
		$balance = $this->user->getBalance();
		$server = $this->serversModel->getServerById($serverid, array('users', 'locations', 'games'));
        $link = $ssh2Lib->connect($server['location_ip'], $server['location_user'], $server['location_password']);
        $auto = $this->autoModel->getAutos(array(),array('games'),array(), $options);
        $this->data['auto'] = $auto;
		foreach($auto as $item){
			if($action == $item['auto_id']) {
				if($server['server_status'] == 1) {
					if($item['auto_act'] == 2) {
						$price = $item['auto_price'];
						if($balance < $price){
							$this->data['status'] = "error";
							$this->data['error'] = "Недостаточно средств";
							return json_encode($this->data);
						}
						$this->serversModel->sendServerAction($serverid, 'reinstall');
						$host = "0.0.0.0";
						$uname = "gs$serverid";
						$dbpass = $server['database_password'];
						$database = "gs$serverid"; 
						$conn = new mysqli($host, $uname, $dbpass, $database);
						$op_data = '';
						if ($mresult = $conn->query("SHOW TABLES"))
						{
							while($row = $mresult->fetch_array(MYSQLI_NUM))
							{
								$conn->query('DROP TABLE IF EXISTS '.$row[0]);
							}
						}	
						$FILE = "scriptfiles/mysql_settings.ini";
						$output = $ssh2Lib->execute($link, 
							"
								cd /home/gs$serverid;	
								rm server.cfg;
								rm -rf gamemodes;
								rm -rf filterscripts;
								rm -rf include;
								rm -rf npcmodes;
								rm -rf scriptfiles;
								wget ".$item['auto_url'].";
								tar -xf ".$item['auto_arch'].";
								rm ".$item['auto_arch'].";				
								mysql -h 0.0.0.0 -u gs$serverid -p".$server['database_password']." gs$serverid < dump.sql;
								rm dump.sql;
								echo 'host = 0.0.0.0'>>".$FILE.";
								echo 'username = gs$serverid'>>".$FILE.";
								echo 'password = ".$server['database_password']."'>>".$FILE.";
								echo 'database = gs$serverid'>>".$FILE.";
								sudo chown -R gs". $server['server_id'] .":gameservers /home/gs". $server['server_id'] ."	
							");
							$ssh2Lib->disconnect($link);;
							$result = $this->serversModel->sendServerAction($serverid, 'start');
							$result = $this->serversModel->parseServerOutput($result);
							if($result['status'] == "OK") {
								$userid = $this->user->getId();
								$this->usersModel->downUserBalance($userid, $price);
								$this->serversModel->updateServer($serverid, array('server_status' => 2));
								$this->data['status'] = "success";
								$this->data['success'] = "Вы успешно установили ".$item['adap_name']." с вашего счёта снято ".$item['auto_price']." р!";
							} 
							else 
							{
								$this->data['status'] = "error";
								$this->data['error'] = $result['description'];
							}
						}
					else 
					{
						$this->serversModel->sendServerAction($serverid, 'reinstall');
						$host = "0.0.0.0";
						$uname = "gs$serverid";
						$dbpass = $server['database_password'];
						$database = "gs$serverid"; 
						$conn = new mysqli($host, $uname, $dbpass, $database);
						$op_data = '';
						if ($mresult = $conn->query("SHOW TABLES"))
						{
							while($row = $mresult->fetch_array(MYSQLI_NUM))
							{
								$conn->query('DROP TABLE IF EXISTS '.$row[0]);
							}
						}	
						$FILE = "scriptfiles/mysql_settings.ini";
						$output = $ssh2Lib->execute($link, 
							"
								cd /home/gs$serverid;	
								rm server.cfg;
								rm -rf gamemodes;
								rm -rf filterscripts;
								rm -rf include;
								rm -rf npcmodes;
								wget ".$item['auto_url'].";
								tar -xf ".$item['auto_arch'].";
								rm ".$item['auto_arch'].";		
								mysql -h 0.0.0.0 -u gs$serverid -p".$server['database_password']." gs$serverid < dump.sql;
								rm dump.sql;
								echo 'host = 0.0.0.0'>>".$FILE.";
								echo 'username = gs$serverid'>>".$FILE.";
								echo 'password = ".$server['database_password']."'>>".$FILE.";
								echo 'database = gs$serverid'>>".$FILE.";
								sudo chown -R gs". $server['server_id'] .":gameservers /home/gs". $server['server_id'] ."	
							");
							$ssh2Lib->disconnect($link);;
							$result = $this->serversModel->sendServerAction($serverid, 'start');
							$result = $this->serversModel->parseServerOutput($result);
							if($result['status'] == "OK") {
								$this->serversModel->updateServer($serverid, array('server_status' => 2));
								$userid = $this->user->getId();
								$this->data['status'] = "success";
								$this->data['success'] = "Вы успешно установили ".$item['auto_name']."!";
							} 
							else 
							{
								$this->data['status'] = "error";
								$this->data['error'] = $result['description'];
							}
						}
					}
				else 
				{
					$this->data['status'] = "error";
					$this->data['error'] = "Сервер должен быть выключен!";
				}
				break;
			}
			
		}

		return json_encode($this->data);
	}
	
	private function validate($serverid) {
		$result = null;
		
		$userid = $this->user->getId();
		
		if(!$this->serversModel->getTotalServers(array('server_id' => (int)$serverid, 'user_id' => (int)$userid))) {
			$result = "Запрашиваемый сервер не существует!";
		}
		return $result;
	}
}
?>
