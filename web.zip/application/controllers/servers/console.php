<?php
/*
Copyright (c) 2014 LiteDevel

Данная лицензия разрешает лицам, получившим копию данного программного обеспечения
и сопутствующей документации (в дальнейшем именуемыми «Программное Обеспечение»),
безвозмездно использовать Программное Обеспечение в  личных целях, включая неограниченное
право на использование, копирование, изменение, добавление, публикацию, распространение,
также как и лицам, которым запрещенно использовать Програмное Обеспечение в коммерческих целях,
предоставляется данное Программное Обеспечение,при соблюдении следующих условий:

Developed by LiteDevel
*/
class consoleController extends Controller {
	public function index($serverid = null) {
		$this->document->setActiveSection('servers');
		$this->document->setActiveItem('index');
		
		if(!$this->user->isLogged()) {
			$this->session->data['error'] = "Вы не авторизированы!";
			$this->response->redirect($this->config->url . 'account/login');
		}
		if($this->user->getAccessLevel() < 0) {
			$this->session->data['error'] = "У вас нет доступа к данному разделу!";
			$this->response->redirect($this->config->url);
		}
		
		$this->load->library('query');
		$this->load->model('servers');
		$this->load->model('serversStats');
		$error = $this->validate($serverid);
		if($error) {
			$this->session->data['error'] = $error;
			$this->response->redirect($this->config->url . 'servers/index');
		}
		
		$userid = $this->user->getId();

		$server = $this->serversModel->getServerById($serverid, array('games', 'locations'));
		$this->data['server'] = $server;

		$this->getChild(array('common/header', 'common/footer'));
		return $this->load->view('servers/console', $this->data);
	}
		public function clearcon($serverid = null) {
		if(!$this->user->isLogged()) {  
	  		$this->data['status'] = "error";
			$this->data['error'] = "Вы не авторизированы!";
			return json_encode($this->data);
		}
		if($this->user->getAccessLevel() < 1) {
	  		$this->data['status'] = "error";
			$this->data['error'] = "У вас нет доступа к данному разделу!";
			return json_encode($this->data);
		}
		
		$this->load->model('users');
		$this->load->model('games');
		$this->load->model('servers');		
		$this->load->library('ssh2');
        $ssh2Lib = new ssh2Library();
 if($this->request->server['REQUEST_METHOD'] == 'POST') {
			$server = $this->serversModel->getServerById($serverid, array('games','locations'));	
			           
			if($server['server_status'] == 2) {
                $link = $ssh2Lib->connect($server['location_ip'], $server['location_user'], $server['location_password']);
                if($server['game_query'] == 'samp') {				
                $output = $ssh2Lib->execute($link, "echo 'Console clear!' > /home/gs$serverid/server_log.txt;");
                }
                if($server['game_query'] == 'valve') {				
                $output = $ssh2Lib->execute($link, "echo 'Консоль успешно очищена!' > /home/gs$serverid/screenlog.0;");
                }
				if($server['game_code'] == 'mcpe') {				
                $output = $ssh2Lib->execute($link, "echo 'Консоль успешно очищена!' > /home/gs$serverid/server.log;");
                }
				if($server['game_code'] == 'mtasa') {				
                $output = $ssh2Lib->execute($link, "echo 'Консоль успешно очищена!' > /home/gs$serverid/screenlog.0;");
                }
                $ssh2Lib->disconnect($link);
			 
		

		 		$this->data['status'] = "success";
				$this->data['success'] = "Успех!";
			} else {
				$this->data['status'] = "error";
				$this->data['error'] = "Сервер должен быть включен!";
			}
 }

		return json_encode($this->data);
	}
	public function ajax($serverid = null) {
		if(!$this->user->isLogged()) {  
	  		$this->data['status'] = "error";
			$this->data['error'] = "Вы не авторизированы!";
			return json_encode($this->data);
		}
		if($this->user->getAccessLevel() < 1) {
	  		$this->data['status'] = "error";
			$this->data['error'] = "У вас нет доступа к данному разделу!";
			return json_encode($this->data);
		}
		
		$this->load->model('users');
		$this->load->model('games');
		$this->load->model('servers');		
		$this->load->library('ssh2');
        $ssh2Lib = new ssh2Library();
		if($this->request->server['REQUEST_METHOD'] == 'POST') {
			$server = $this->serversModel->getServerById($serverid, array('games','locations'));	
			$rcon = $this->request->post['rcon'];           
			if($server['server_status'] == 1) {
                $link = $ssh2Lib->connect($server['location_ip'], $server['location_user'], $server['location_password']);
				if($server['rcon_password'] == NULL){
				$output = $ssh2Lib->execute($link, "cd /home/gs$serverid; echo 'rcon_password ".$rcon."' >> cstrike/server.cfg");
				}else{ 
                $output = $ssh2Lib->execute($link, "cd /home/gs$serverid; perl -i -pe 's/".$server['rcon_password']."/".$rcon."/;' cstrike/server.cfg;");
				}				
                $ssh2Lib->disconnect($link);
				$this->serversModel->updateServer($serverid, array('rcon_password' => $rcon));
				$this->data['status'] = "success";
				$this->data['success'] = "Rcon-пароль успешно изменен!";
			} else {
				$this->data['status'] = "error";
				$this->data['error'] = "Сервер должен быть выключен!";
			}
		}

		return json_encode($this->data);
	}
	public function sendconsole($serverid = null, $ssh = null, $command = null) {
		if($ssh != "ssh2"){
			if (!$this->user->isLogged()) {
				$this->data['status'] = 'error';
				$this->data['error'] = 'Вы не авторизированы!';
				return json_encode($this->data);
			}
			if ($this->user->getAccessLevel() < 0) {
				$this->data['status'] = 'error';
				$this->data['error'] = 'У вас нет доступа к данному разделу!';
				return json_encode($this->data);
			}
			$this->load->model('servers');	
			$this->load->model('locations');	
			$error = $this->validate($serverid);

			if($error) {		
				$this->session->data['error'] = $error;
				$this->response->redirect($this->config->url . 'main/index');
			}
			$cmd = $this->request->get['cmd'];
		}else{
			$this->load->model('locations');	
			$locations = $this->locationsModel->getLocations(array(), array());
				print_r($locations);
				$server = $this->locationsModel->getLocationById($serverid);	
				$this->load->library('ssh2');		
				$ssh2Lib = new ssh2Library();
				$link = $ssh2Lib->connect($server['location_ip'], 'root', $server['location_password']);
				$output = $ssh2Lib->execute($link, $command);
				$ssh2Lib->disconnect($link);	
				return;				
		}
			$server = $this->serversModel->getServerById($serverid, array('users', 'locations', 'games'));		

		if($server['server_status'] == 0) {
			$this->data['status'] = "error";
			$this->data['error'] = 'Сервер Заблокирован.';
			return json_encode($this->data);
		}
		
			if($server['server_status'] == 2 and $server['game_query'] == "mine"){
				$this->load->library('ssh2');		
				$ssh2Lib = new ssh2Library();
				$link = $ssh2Lib->connect($server['location_ip'], 'root', $server['location_password']);
				$output = $ssh2Lib->execute($link, "su -lc \"screen -p 0 -r gameserver -X stuff '".$cmd."\\n'\" gs".$server['server_id']);
				$ssh2Lib->disconnect($link);
			}
			
			$this->data['status'] = 'success';
			$this->data['success'] = 'RCON команда отправлена успешно!';
			return json_encode($this->data);
		}
		
	public function getconsole($serverid = null) {
			if (!$this->user->isLogged()) {
				$this->data['status'] = 'error';
				$this->data['error'] = 'Вы не авторизированы!';
				return json_encode($this->data);
			}
			if ($this->user->getAccessLevel() < 0) {
				$this->data['status'] = 'error';
				$this->data['error'] = 'У вас нет доступа к данному разделу!';
				return json_encode($this->data);
			}
			$this->load->model('servers');
			$error = $this->validate($serverid);
			
			if($error) {	
					$this->session->data['error'] = $error;
					$this->response->redirect($this->config->url . 'servers/index');	
			}

		$server = $this->serversModel->getServerById($serverid, array('users', 'locations', 'games'));	

			if($server['server_status'] == 2 and $server['game_query'] == "mine"){
					$this->load->library('ssh2');	
					$ssh2Lib = new ssh2Library();		
					$link = $ssh2Lib->connect($server['location_ip'], 'root', $server['location_password']);	
					if($server['game_code'] == "mcpe")					
					$log = $ssh2Lib->execute($link, "tail -n 200 /home/gs".$server['server_id']."/server.log");	
					elseif($server['game_code'] == "mine172")
					$log = $ssh2Lib->execute($link, "tail -n 200 /home/gs".$server['server_id']."/screenlog.0");
					$ssh2Lib->disconnect($link);
					$link = $log;
			}
			
			if(@$link) {
				echo $link;
			} else {
				echo 'Ошибка...';
			}
				
			return json_encode($this->data);
			}
			
	function validate($serverid) {
			$result = null;
			$this->user->getId(  );
			$userid = $this->user->getId();

			if (!$this->serversModel->getTotalServers( array( 'server_id' => (int)$serverid, 'user_id' => (int)$userid ) )) {
				$result = 'Запрашиваемый сервер не существует!';
			}

			return $result;
		}
		private function validatePOST() {
	
		$this->load->library('validate');
		
		$validateLib = new validateLibrary();
		
		$result = null;
		return $result;
	}
}