<?php
/*
* @LitePanel
* @Developed by QuickDevel
*/
class orderController extends Controller {
	public function index() {
		$this->document->setActiveSection('servers');
		$this->document->setActiveItem('order');
		
		if(!$this->user->isLogged()) {
			$this->session->data['error'] = "Вы не авторизированы!";
			$this->response->redirect($this->config->url . 'account/login');
		}
		if($this->user->getAccessLevel() < 0) {
			$this->session->data['error'] = "У вас нет доступа к данному разделу!";
			$this->response->redirect($this->config->url);
		}
		
		$this->load->model('games');
		$this->load->model('locations');
		
		$games = $this->gamesModel->getGames(array('game_status' => 1));
		if(count($games) <= 0) {
			$this->session->data['error'] = "На данный момент нет доступных игр!";
			$this->response->redirect($this->config->url);
		}
		
		$locations = $this->locationsModel->getLocations(array('location_status' => 1));
		if(count($games) <= 0) {
			$this->session->data['error'] = "На данный момент нет доступных локаций!";
			$this->response->redirect($this->config->url);
		}
		
		$this->data['games'] = $games;
		$this->data['locations'] = $locations;
		
		$this->getChild(array('common/header', 'common/footer'));
		return $this->load->view('servers/order', $this->data);
	}
	
	public function promo() {
		if(!$this->user->isLogged()) {  
	  		$this->data['status'] = "error";
			$this->data['error'] = "Вы не авторизированы!";
			return json_encode($this->data);
		}
		if($this->user->getAccessLevel() < 1) {
	  		$this->data['status'] = "error";
			$this->data['error'] = "У вас нет доступа к данному разделу!";
			return json_encode($this->data);
		}
		
		$this->load->model('users');
		
		if($this->request->server['REQUEST_METHOD'] == 'POST') {
			$code = $this->request->post['code'];
			$skidka = $this->usersModel->getSkidkaByCode($code, false);
			$kofficent=(100-$skidka['skidka'])/100;
			if($skidka['skidka'] == NULL){
				$this->data['status'] = "error";
				$this->data['error'] = "Данного кода не существует";
			}else{
				$this->data['status'] = "success";
				$this->data['success'] = "Вы активировали скидку ".$skidka['skidka']."%";
				$this->data['skidka'] = $kofficent;
			}
		}

		return json_encode($this->data);
	}
	
	public function ajax() {
		if(!$this->user->isLogged()) {  
	  		$this->data['status'] = "error";
			$this->data['error'] = "Вы не авторизированы!";
			return json_encode($this->data);
		}
		if($this->user->getAccessLevel() < 1) {
	  		$this->data['status'] = "error";
			$this->data['error'] = "У вас нет доступа к данному разделу!";
			return json_encode($this->data);
		}
		
		$this->load->model('users');
		$this->load->model('games');
		$this->load->model('locations');
		$this->load->model('servers');
		
		if($this->request->server['REQUEST_METHOD'] == 'POST') {
			$errorPOST = $this->validatePOST();
			if(!$errorPOST) {
				$gameid = @$this->request->post['gameid'];
				$locationid = @$this->request->post['locationid'];
				$slots = @$this->request->post['slots'];
				$months = @$this->request->post['months'];
				$password = @$this->request->post['password'];
				$password2 = @$this->request->post['password2'];
				
				$userid = $this->user->getId();
				$balance = $this->user->getBalance();
				
				$game = $this->gamesModel->getGameById($gameid);
				$port = $this->serversModel->getServerNewPort($locationid, $game['game_min_port'], $game['game_max_port']);
				$code = $this->request->post['promo'];
				$skidka = $this->usersModel->getSkidkaByCode($code,true);$kofficent=(100-$skidka['skidka'])/100;				
				if($port) {
					$price = $slots * $game['game_price'];
				
					switch($months) {
						case "3":
							$months = 3;
							$price = $price * 0.95;
							break;
						case "6":
							$months = 6;
							$price = $price * 0.90;
							break;
						case "12":
							$months = 12;
							$price = $price * 0.85;
							break;
						default:
							$months = 1;
					}
				
					$price = $price * $months;
				
					if($skidka['skidka'] != NULL){
						$price = $price * $kofficent;
					}
				
					if($balance >= $price) {
						$serverData = array(
							'user_id'			=> $userid,
							'game_id'			=> $gameid,
							'location_id'		=> $locationid,
							'server_mysql'			=> 0,
							'server_slots'		=> $slots,
							'server_port'		=> $port,
							'server_password'	=> $password,
							'server_status'		=> 3,
							'server_months'		=> $months
						);
					
						$serverid = $this->serversModel->createServer($serverData);
						$this->usersModel->downUserBalance($userid, $price);
						$getpref = $price - (70 / 100 * $price);
						$this->usersModel->upUserBalance($user['ref'], $getpref);
				        $this->usersModel->upUserRMoney($user['ref'], $getpref);
				        $this->usersModel->upUserRMoney($userid, 10.00);
						$this->data['status'] = "success";
						$this->data['success'] = "Сервер поставлен в очередь на установку.";
						$this->data['id'] = $serverid;	
						// Установка сервера
						$this->serversModel->sendServerAction($serverid, "install");
						// Смена статуса на "Выключен"
						$this->serversModel->updateServer($serverid, array('server_status' => 1));						
					} else {
						$this->data['status'] = "error";
						$this->data['error'] = "На Вашем счету недостаточно средств!";
					}
				} else {
					$this->data['status'] = "error";
					$this->data['error'] = "На выбранной Вами локации нет свободных портов для данной игры!";
				}
			} else {
				$this->data['status'] = "error";
				$this->data['error'] = $errorPOST;
			}
		}

		return json_encode($this->data);
	}
	
	private function validatePOST() {
		$this->load->library('validate');
		
		$validateLib = new validateLibrary();
		
		$result = null;
		
		$gameid = @$this->request->post['gameid'];
		$locationid = @$this->request->post['locationid'];
		$slots = @$this->request->post['slots'];
		$months = @$this->request->post['months'];
		$password = @$this->request->post['password'];
		$password2 = @$this->request->post['password2'];
		
		if(!$this->gamesModel->getTotalGames(array('game_id' => (int)$gameid, 'game_status' => 1))) {
			$result = "Вы указали несуществующую игру!";
		}
		elseif(!$this->locationsModel->getTotalLocations(array('location_id' => (int)$locationid, 'location_status' => 1))) {
			$result = "Вы указали несуществующую локацию!";
		}
		elseif(!$this->gamesModel->validateSlots($gameid, $slots)) {
			$result = "Вы указали недопустимое количество слотов!";
		}
		elseif(!$validateLib->password($password)) {
			$result = "Пароль должен содержать от 6 до 32 латинских букв, цифр и знаков <i>,.!?_-</i>!";
		}
		elseif($password != $password2) {
			$result = "Введенные вами пароли не совпадают!";
		}
		return $result;
	}
}
?>
