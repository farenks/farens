<?php
$config = array(
'title' => 'Aquza PL',
'description' => 'Aquza PL Game Hosting',
'keywords' => 'Aquza PL game hosting game servers server gta samp mta cs cs16 cs1.6 css source',
'url' => 'http://domen.ru/',
'token'			=>		'crontoke12',
'db_type'		=>		'mysql',
'db_hostname'	=>		'localhost',
'db_username'	=>		'admin',
'db_password'	=>		'parol',
'db_database'	=>		'host',
'mail_from' => 'support@vulkertech.ga',
'mail_sender' => 'Support',
'payok' => '1',
'payok_id' => 'ID',
'payok_key' => 'SecretKey',
'portPrice' => '0',
'public' => 'idVKGroup',
'recaptcha' => 'KeyCaptcha',
'register' => '1',
'close' => 'off'
);
?>