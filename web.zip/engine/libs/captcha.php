<?php
class captchaLibrary {
	public $width = 110;
	public $height = 20;
	public $font = 'tahoma.ttf';
	private $code;
	
	function __construct() { 
		$this->code = substr(md5(mt_rand()), 10, 8); 
	}

	function getCode(){
		return $this->code;
	}

	function showImage() {
		$font = ENGINE_DIR . 'fonts/' . $this->font;
		$img = imagecreatetruecolor($this->width, $this->height);
		$width = imagesx($img);
		$height = imagesy($img);
		$font_size = 16;
		$angle = 0;
		$x = 10;
		$y = 18;

		$text_color = imagecolorallocate($img, rand(0, 255), rand(0, 255), rand(0, 255));
		$bg = imagecolorallocatealpha($img, 0, 0, 0, 127);

		imagesavealpha($img, true);
		imagefill($img, 0, 0, $bg);
		
		for($i = 0; $i < 3; $i++) {
			imageline($img, rand(1, $width/2), rand(1, $height), rand($width/2, $width), rand(1, $height), $text_color);
		}

		header('Content-type: image/png');
		imagettftext($img, $font_size, $angle, $x, $y, $text_color, $font, $this->code);
		imagepng($img);
		imagedestroy($img);		
	}
}
?>